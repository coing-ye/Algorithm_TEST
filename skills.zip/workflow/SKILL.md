---
name: workflow
description: Drive a ROADMAP.md-based project workflow in Codex. Use when the user wants to start or continue multi-step work, plan tasks, manage roadmap-backed progress, resume paused work from ROADMAP.md, or explicitly invokes `$workflow`.
---

# Workflow

Run a ROADMAP-first workflow router in Codex with explicit `$workflow` invocation. Treat `ROADMAP.md` as the durable state between sessions and `update_plan` as the in-session tracker.

## Companion Skills

Use the narrower companion skill when the user is explicit about intent:

- `$workflow-init`: inspect the project state, recover from `ROADMAP.md`, or bootstrap a new workflow
- `$workflow-plan`: create or refresh `ROADMAP.md` from a request
- `$workflow-run`: execute the next unblocked roadmap task
- `$workflow-complete`: close out the current task, update progress, and decide the next step
- `$workflow-sync`: reconcile roadmap state after work, review, or blockers

Optional adjacent skills:

- `$team-refactor`: use when the work is a large refactor and the user wants multi-perspective analysis or parallel execution planning
- `$team-debug`: use when the work is an ambiguous or cross-module bug and the user wants multi-hypothesis root-cause debugging
- `$team-review`: use when the user explicitly wants a multi-angle review after meaningful changes or before final signoff

Use `$workflow` when the user wants to start, continue, restore, or generally "run the workflow" without specifying which phase they need. In that case, this skill should behave like a router and choose the appropriate phase behavior instead of staying as prose only.

## Recommended Entry Points

Treat these as the normal user-facing workflow stack:

- `$workflow`: default entrypoint for start, restore, continue, and ordinary multi-step work
- `$team-refactor`: explicit branch for large refactor analysis or coordinated refactor execution
- `$team-debug`: explicit branch for ambiguous, intermittent, or cross-module root-cause debugging
- `$team-review`: explicit branch for a multi-angle second-pass review

Treat `$workflow-init`, `$workflow-plan`, `$workflow-run`, `$workflow-complete`, and `$workflow-sync` as internal or advanced phase skills. They should remain available for explicit power-user calls, but ordinary usage should start from `$workflow`.

## Quick Start

1. Detect the workspace root.
   - Prefer the git root.
   - Fall back to the current working directory.
2. Read `ROADMAP.md` first if it exists.
   - Prefer using `scripts/roadmap_state.py` to summarize the current state before making assumptions.
   - Search for `🔄 진행 중`, unchecked checklist items, `모드:`, and `진행률:`.
   - Recover the first active section before creating a new plan.
3. Classify the situation before acting.
   - No roadmap and no clear active work -> behave like `$workflow-init`.
   - New request requiring analysis or planning -> behave like `$workflow-plan`.
   - Active or resumed task ready to execute -> behave like `$workflow-run`.
   - Task just finished or progress needs a next-step decision -> behave like `$workflow-complete`.
   - Work happened outside the flow and roadmap drifted -> behave like `$workflow-sync`.
4. Keep `update_plan` aligned with the active roadmap tasks.
5. Execute the next unblocked task or ask one concise question only when a risky decision blocks progress.
6. After each completed task, update `ROADMAP.md` with completion status, `변경:` notes, and `진행률:`.

## Codex Guardrails

- Keep workflow state in `ROADMAP.md` and `update_plan`. Do not rely on hidden session metadata.
- Use one short direct question only when stack choice, task selection, or a public-contract decision truly blocks progress.
- Do not promise menu widgets, native task objects, automatic PR context import, hook automation, or automatic review/commit/push behavior.
- Default to direct execution in the main Codex session. Use subagents only when the user explicitly wants delegation or parallel agent work.
- Keep `$team-refactor`, `$team-debug`, and `$team-review` opt-in. Workflow may recommend them, but should not silently turn ordinary work into a multi-agent routine.

## Router Flow

Use this decision order whenever `$workflow` is invoked without a more specific phase:

1. Detect the workspace root and inspect `ROADMAP.md` if present.
   - Prefer `scripts/roadmap_state.py <root> --json` when you need a fast state summary.
2. Determine whether the user supplied a new request in this turn.
3. Route using the first matching case:
   - Existing roadmap with `🔄 진행 중` -> resume with `$workflow-run`
   - Existing roadmap with unchecked items and `모드: 자동진행` -> continue with `$workflow-run`
   - Existing roadmap with unchecked items and `모드: 개별선택` or `모드: 대기 중` -> recommend the next task and ask one short plain-text question
   - Existing roadmap with `state=complete` and `closeout_needed=true` from `roadmap_state.py` -> behave like `$workflow-complete`
   - Existing roadmap with drift between files and roadmap -> behave like `$workflow-sync`
   - Large refactor request where the user wants multi-angle analysis or parallel refactor planning -> recommend `$team-refactor` before or alongside `$workflow-plan`
   - Ambiguous bug request where the failure mode spans multiple subsystems, remains intermittent, or needs competing hypotheses -> recommend `$team-debug` before or alongside `$workflow-run`
   - No roadmap, no manifest that reveals the stack, and a greenfield request -> behave like `$workflow-init` first and ask one short environment question before planning
   - No roadmap and a concrete request -> behave like `$workflow-plan`
   - No roadmap and no concrete request -> behave like `$workflow-init`

4. After a sub-phase completes, reassess the state instead of assuming the workflow is done.

## Decision Tree

- Existing `ROADMAP.md` with unfinished work:
  Restore from the first active section. Prefer an existing `🔄 진행 중` task; otherwise choose the lowest-numbered unblocked `- [ ]` item. If the user asked to continue or execute, behave like `$workflow-run`.
- Existing `ROADMAP.md` with only completed work:
  Summarize completion and propose follow-up work only if the user asks or there is an obvious next step. If `roadmap_state.py` reports `closeout_needed=true`, behave like `$workflow-complete` before treating the workflow as fully closed out.
- No roadmap but the user has a concrete request:
  Analyze the codebase and create or refresh `ROADMAP.md` before large or multi-step work. If the request looks greenfield and nearby manifests such as `package.json`, `pyproject.toml`, `Cargo.toml`, `go.mod`, or `Gemfile` do not reveal the environment, ask one short plain-text question to choose the stack before behaving like `$workflow-plan`.
- Large refactor request:
  If the user wants a refactor strategy from multiple angles, or the scope clearly spans many files or architectural boundaries, recommend `$team-refactor` as an explicit parallel-analysis branch before committing to implementation.
- Ambiguous or high-risk bug request:
  If the work is mainly root-cause debugging, especially for intermittent failures, stateful bugs, concurrency issues, or failures spread across multiple modules, recommend `$team-debug` as the explicit multi-hypothesis debugging branch.
- No roadmap and the user did not give a concrete request:
  Inspect the repository or current directory state, summarize what appears active, and behave like `$workflow-init`.
- Small or low-risk requests:
  You may skip roadmap creation, but still keep `update_plan` accurate when the task is more than trivial.
- `모드: 자동진행`:
  Continue through the next unblocked tasks without waiting for repeated confirmation.
- `모드: 개별선택` or `모드: 대기 중`:
  Recommend the next task, but ask a concise plain-text question if the user needs to choose. Codex Default mode has no menu-style question tool here, so use one short direct question instead of inventing a widget.
- Greenfield bootstrap with no detectable stack:
  Ask one short plain-text environment question before creating the first roadmap, for example `새 프로젝트라면 어떤 환경으로 시작할까요? Node.js CLI, React 웹앱, Python 스크립트 중 하나로 정하면 그 기준으로 ROADMAP을 만들겠습니다.`
- Work already happened outside the workflow:
  Reconcile `ROADMAP.md`, `변경:` lines, and `update_plan` as `$workflow-sync`.
- Important work just completed and confidence still matters:
  Recommend `$team-review` as an explicit follow-up when the task touched security, auth, payments, migrations, shared infrastructure, or a wide refactor and the user wants a second pass before signoff.

## Planning Rules

- Default to one active section named `## 현재 작업 (YYYY-MM-DD)`.
- When a new feature requires design choices that could affect public interfaces, add an optional `## 설계 결정` section above the active tasks.
- Put `모드:` immediately below the section header.
- Keep checklist lines in the form `- [ ] N. 작업명 (owner)`.
- For new Codex-made roadmaps, default the owner to `(codex)`.
- If an existing roadmap already uses older labels such as `(impl-sonnet)`, preserve them as execution hints rather than rewriting them.
- Express dependencies as `[blockedBy: N]`.
- End the active checklist section with `진행률: X/Y (Z%)`.
- When execution tuning should survive session breaks, add an optional `## 전략 설정` section with durable hints such as stricter debug escalation or parallelism limits.
- Put detailed instructions outside the checklist, for example under `## Task Briefs`.
- Preserve valid completed items and `변경:` notes when refreshing an existing roadmap.

## Execution Rules

- In Codex Default mode, do the work directly unless the user explicitly asks for delegation or parallel agent work.
- Keep the workflow shape "analyze -> select -> execute -> complete", but implement it with Codex-native tools and direct execution.
- Before edits, inspect local context and `git status --short` when inside a repository.
- Make reasonable assumptions for low-risk gaps and record them in the roadmap or final summary.
- If a missing decision could change a public API, schema, migration, billing behavior, or external contract, ask one concise question instead of guessing.
- Keep roadmap state and `update_plan` synchronized at major transitions. When the roadmap state is `blocked` or `cancelled`, record that detail in `ROADMAP.md` and keep the corresponding plan step `pending` because Codex only supports `pending`, `in_progress`, and `completed`.
- Prefer finishing the current unblocked task before expanding the plan.
- For debugging, fix root causes rather than papering over symptoms.
- Do not auto-commit, push, or claim review automation as part of the core workflow unless the user explicitly asks for it.
- Do not auto-spawn `$team-review`, `$team-refactor`, or `$team-debug` inside routine workflow execution. Recommend them only when their extra analysis is justified or the user explicitly asked for them.
- If `모드: 자동진행` is set, move from run to complete to the next runnable task without repeated confirmation unless blocked.

## Completion Rules

- Mark completed items as `- [x]`.
- Append the completion date on the same line when useful.
- Add a following `변경:` line summarizing the key files and changes.
- Remove or replace stale `🔄 진행 중` markers after the task completes.
- If a task fails and progress should stop, record the reason in `모드: 중단 (...)` or near the task line, then explain the blocker to the user.
- If a task is intentionally abandoned, record the reason near the task line. Use section-level `모드: 취소 (...)` only when the whole active section should stop.
- After completion, decide whether to continue automatically, recommend the next task, or summarize full completion. Review and git actions stay opt-in.
- If the work merits an explicit second-pass review, suggest `$team-review` once as a follow-up option rather than silently invoking it.

## Reference

Read [references/workflow-reference.md](references/workflow-reference.md) for the detailed roadmap contract, recovery heuristics, and a Codex-oriented phase mapping.
