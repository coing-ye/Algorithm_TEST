import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).resolve().parents[1] / "scripts" / "roadmap_state.py"
SPEC = importlib.util.spec_from_file_location("roadmap_state", MODULE_PATH)
roadmap_state = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = roadmap_state
SPEC.loader.exec_module(roadmap_state)


class RoadmapStateTests(unittest.TestCase):
    def summarize_text(self, text: str):
        with tempfile.TemporaryDirectory() as tmp:
            roadmap = Path(tmp) / "ROADMAP.md"
            roadmap.write_text(text, encoding="utf-8")
            return roadmap_state.summarize(roadmap)

    def summarize_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            return roadmap_state.summarize(Path(tmp) / "ROADMAP.md")

    def test_no_roadmap(self):
        summary = self.summarize_missing()
        self.assertEqual(summary["state"], "no_roadmap")
        self.assertIsNone(summary["next_runnable_task"])

    def test_waiting_selection_prefers_first_runnable_task(self):
        summary = self.summarize_text(
            """# ROADMAP

## 현재 작업 (2026-03-19)
모드: 개별선택
- [x] 1. 구조 분석 (codex) ✅ 2026-03-19
  변경: ROADMAP.md (범위 정리)
- [ ] 2. 구현 (codex) [blockedBy: 1]
- [ ] 3. 검증 (codex) [blockedBy: 2]
진행률: 1/3 (33%)
"""
        )
        self.assertEqual(summary["state"], "waiting_selection")
        self.assertEqual(summary["next_runnable_task"]["number"], 2)
        self.assertEqual(summary["blocked_task_numbers"], [3])
        self.assertFalse(summary["closeout_needed"])

    def test_active_marker_yields_in_progress(self):
        summary = self.summarize_text(
            """# ROADMAP

## 현재 작업 (2026-03-19)
모드: 자동진행
- [x] 1. 분석 (codex) ✅ 2026-03-19
  변경: ROADMAP.md (범위 정리)
- [ ] 2. 구현 (codex) [blockedBy: 1]
🔄 진행 중: 2. 구현
- [ ] 3. 검증 (codex) [blockedBy: 2]
진행률: 1/3 (33%)
"""
        )
        self.assertEqual(summary["state"], "in_progress")
        self.assertEqual(summary["active_task"]["number"], 2)
        self.assertEqual(summary["next_runnable_task"]["number"], 2)

    def test_stopped_mode_yields_blocked(self):
        summary = self.summarize_text(
            """# ROADMAP

## 현재 작업 (2026-03-19)
모드: 중단 (2번 작업에서 타입 충돌 발생)
- [x] 1. 분석 (codex) ✅ 2026-03-19
  변경: ROADMAP.md (범위 정리)
- [ ] 2. 구현 (codex) [blockedBy: 1] ❌ 실패 (타입 충돌)
- [ ] 3. 검증 (codex) [blockedBy: 2]
진행률: 1/3 (33%)
"""
        )
        self.assertEqual(summary["state"], "blocked")
        self.assertEqual(summary["active_task"]["number"], 2)
        self.assertIsNone(summary["next_runnable_task"])
        self.assertEqual(summary["blocked_task_numbers"], [2, 3])

    def test_cancelled_mode_yields_cancelled(self):
        summary = self.summarize_text(
            """# ROADMAP

## 현재 작업 (2026-03-19)
모드: 취소 (요구사항 변경)
- [x] 1. 분석 (codex) ✅ 2026-03-19
  변경: ROADMAP.md (범위 정리)
- [ ] 2. 구현 (codex) [blockedBy: 1] ❌ 취소 (요구사항 변경)
- [ ] 3. 검증 (codex) [blockedBy: 2]
진행률: 1/3 (33%)
"""
        )
        self.assertEqual(summary["state"], "cancelled")
        self.assertEqual(summary["active_task"]["number"], 2)
        self.assertIsNone(summary["next_runnable_task"])
        self.assertEqual(summary["cancelled_task_numbers"], [2])
        self.assertEqual(summary["blocked_task_numbers"], [3])

    def test_cancelled_history_does_not_mask_new_active_section(self):
        summary = self.summarize_text(
            """# ROADMAP

## 현재 작업 (2026-03-18)
모드: 취소 (요구사항 변경)
- [ ] 1. 구작업 (codex) ❌ 취소 (요구사항 변경)
진행률: 0/1 (0%)

## 현재 작업 (2026-03-19)
모드: 자동진행
- [ ] 1. 신작업 (codex)
진행률: 0/1 (0%)
"""
        )
        self.assertEqual(summary["section_title"], "현재 작업 (2026-03-19)")
        self.assertEqual(summary["state"], "ready_to_run")
        self.assertEqual(summary["next_runnable_task"]["title"], "신작업")

    def test_current_work_section_beats_review_findings_when_both_have_unfinished_tasks(self):
        summary = self.summarize_text(
            """# ROADMAP

## 리뷰 발견사항 (2026-03-18)
모드: 대기 중
- [ ] 1. 회귀 테스트 추가 (codex)
진행률: 0/1 (0%)

## 현재 작업 (2026-03-19)
모드: 자동진행
- [ ] 1. 핵심 구현 (codex)
진행률: 0/1 (0%)
"""
        )
        self.assertEqual(summary["section_title"], "현재 작업 (2026-03-19)")
        self.assertEqual(summary["state"], "ready_to_run")
        self.assertEqual(summary["next_runnable_task"]["title"], "핵심 구현")

    def test_complete_section_is_retained(self):
        summary = self.summarize_text(
            """# ROADMAP

## Working Context
요청: 샘플

## 현재 작업 (2026-03-19)
모드: 자동진행
- [x] 1. 분석 (codex) ✅ 2026-03-19
  변경: ROADMAP.md (범위 정리)
- [x] 2. 구현 (codex) ✅ 2026-03-19 [blockedBy: 1]
  변경: src/index.js (기능 구현)
진행률: 2/2 (100%)
"""
        )
        self.assertEqual(summary["state"], "complete")
        self.assertEqual(summary["section_title"], "현재 작업 (2026-03-19)")
        self.assertEqual(len(summary["tasks"]), 2)
        self.assertFalse(summary["closeout_needed"])
        self.assertEqual(summary["missing_change_task_numbers"], [])

    def test_complete_section_without_change_notes_flags_closeout_needed(self):
        summary = self.summarize_text(
            """# ROADMAP

## 현재 작업 (2026-03-19)
모드: 자동진행
- [x] 1. 분석 (codex) ✅ 2026-03-19
- [x] 2. 구현 (codex) ✅ 2026-03-19 [blockedBy: 1]
진행률: 2/2 (100%)
"""
        )
        self.assertEqual(summary["state"], "complete")
        self.assertTrue(summary["closeout_needed"])
        self.assertEqual(summary["missing_change_task_numbers"], [1, 2])


if __name__ == "__main__":
    unittest.main()
