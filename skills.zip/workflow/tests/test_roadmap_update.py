import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPTS_DIR = Path(__file__).resolve().parents[1] / "scripts"


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


roadmap_state = load_module("roadmap_state", SCRIPTS_DIR / "roadmap_state.py")
roadmap_update = load_module("roadmap_update", SCRIPTS_DIR / "roadmap_update.py")


class RoadmapUpdateTests(unittest.TestCase):
    def write_roadmap(self, text: str) -> Path:
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        roadmap = Path(tmp.name) / "ROADMAP.md"
        roadmap.write_text(text, encoding="utf-8")
        return roadmap

    def test_start_sets_active_marker(self):
        roadmap = self.write_roadmap(
            """# ROADMAP

## 현재 작업 (2026-03-19)
모드: 자동진행
- [ ] 1. 분석 (codex)
- [ ] 2. 구현 (codex) [blockedBy: 1]
진행률: 0/2 (0%)
"""
        )
        roadmap_update.run_start(roadmap, 1)
        summary = roadmap_state.summarize(roadmap)
        self.assertEqual(summary["state"], "in_progress")
        self.assertEqual(summary["active_task"]["number"], 1)

    def test_start_rejects_blocked_task(self):
        roadmap = self.write_roadmap(
            """# ROADMAP

## 현재 작업 (2026-03-19)
모드: 자동진행
- [ ] 1. 분석 (codex)
- [ ] 2. 구현 (codex) [blockedBy: 1]
진행률: 0/2 (0%)
"""
        )
        with self.assertRaisesRegex(ValueError, "blocked by unfinished dependencies"):
            roadmap_update.run_start(roadmap, 2)

    def test_complete_marks_task_and_recalculates_progress(self):
        roadmap = self.write_roadmap(
            """# ROADMAP

## 현재 작업 (2026-03-19)
모드: 자동진행
- [ ] 1. 분석 (codex)
- [ ] 2. 구현 (codex) [blockedBy: 1]
진행률: 0/2 (0%)
"""
        )
        roadmap_update.run_complete(
            roadmap,
            task_number=1,
            date="2026-03-19",
            change="ROADMAP.md (범위 정리)",
            activate_next=True,
        )
        text = roadmap.read_text(encoding="utf-8")
        self.assertIn("- [x] 1. 분석 (codex) ✅ 2026-03-19", text)
        self.assertIn("  변경: ROADMAP.md (범위 정리)", text)
        self.assertIn("진행률: 1/2 (50%)", text)
        self.assertIn("🔄 진행 중: 2. 구현", text)

    def test_block_sets_stop_mode_and_failure_marker(self):
        roadmap = self.write_roadmap(
            """# ROADMAP

## 현재 작업 (2026-03-19)
모드: 자동진행
- [x] 1. 분석 (codex) ✅ 2026-03-19
  변경: ROADMAP.md (범위 정리)
- [ ] 2. 구현 (codex) [blockedBy: 1]
진행률: 1/2 (50%)
"""
        )
        roadmap_update.run_block(roadmap, 2, "타입 충돌")
        summary = roadmap_state.summarize(roadmap)
        self.assertEqual(summary["state"], "blocked")
        self.assertEqual(summary["active_task"]["number"], 2)
        self.assertIn("중단 [이전: 자동진행] (타입 충돌)", roadmap.read_text(encoding="utf-8"))
        self.assertIn("❌ 실패 (타입 충돌)", roadmap.read_text(encoding="utf-8"))

    def test_complete_after_block_restores_mode_and_activates_next(self):
        roadmap = self.write_roadmap(
            """# ROADMAP

## 현재 작업 (2026-03-19)
모드: 자동진행
- [x] 1. 분석 (codex) ✅ 2026-03-19
  변경: ROADMAP.md (범위 정리)
- [ ] 2. 구현 (codex) [blockedBy: 1]
- [ ] 3. 검증 (codex) [blockedBy: 2]
진행률: 1/3 (33%)
"""
        )
        roadmap_update.run_block(roadmap, 2, "타입 충돌")
        roadmap_update.run_complete(
            roadmap,
            task_number=2,
            date="2026-03-19",
            change="src/x.ts (fix)",
            activate_next=True,
        )
        text = roadmap.read_text(encoding="utf-8")
        summary = roadmap_state.summarize(roadmap)
        self.assertIn("모드: 자동진행", text)
        self.assertEqual(summary["state"], "in_progress")
        self.assertEqual(summary["active_task"]["number"], 3)
        self.assertEqual(summary["next_runnable_task"]["number"], 3)

    def test_cancel_marks_task_but_keeps_other_work_runnable(self):
        roadmap = self.write_roadmap(
            """# ROADMAP

## 현재 작업 (2026-03-19)
모드: 자동진행
- [x] 1. 분석 (codex) ✅ 2026-03-19
  변경: ROADMAP.md (범위 정리)
- [ ] 2. 구현 (codex) [blockedBy: 1]
- [ ] 3. 문서 정리 (codex)
진행률: 1/3 (33%)
"""
        )
        roadmap_update.run_cancel(roadmap, 2, "요구사항 변경")
        summary = roadmap_state.summarize(roadmap)
        text = roadmap.read_text(encoding="utf-8")
        self.assertEqual(summary["state"], "ready_to_run")
        self.assertEqual(summary["next_runnable_task"]["number"], 3)
        self.assertEqual(summary["cancelled_task_numbers"], [2])
        self.assertIn("모드: 자동진행", text)
        self.assertIn("❌ 취소 (요구사항 변경)", text)


if __name__ == "__main__":
    unittest.main()
