#!/usr/bin/env python3
"""Update ROADMAP.md workflow state for Codex workflow skills."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

import roadmap_state


SUCCESS_RE = re.compile(r"\s+✅\s+\d{4}-\d{2}-\d{2}")
FAIL_RE = re.compile(r"\s+❌\s*실패\s*\([^)]*\)")
CANCEL_RE = re.compile(r"\s+❌\s*취소\s*\([^)]*\)")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Directory containing ROADMAP.md or a direct ROADMAP.md path",
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON summary after editing")
    subparsers = parser.add_subparsers(dest="command", required=True)

    start_parser = subparsers.add_parser("start", help="Set the active marker for a task")
    start_parser.add_argument("--task", type=int, required=True, help="Task number to activate")

    complete_parser = subparsers.add_parser("complete", help="Mark a task complete")
    complete_parser.add_argument("--task", type=int, required=True, help="Task number to complete")
    complete_parser.add_argument("--date", required=True, help="Completion date in YYYY-MM-DD")
    complete_parser.add_argument("--change", required=True, help="Summary for the following 변경: line")
    complete_parser.add_argument(
        "--activate-next",
        action="store_true",
        help="Set the next runnable task as active after completion",
    )

    block_parser = subparsers.add_parser("block", help="Record a blocked task and stop mode")
    block_parser.add_argument("--task", type=int, required=True, help="Task number to block")
    block_parser.add_argument("--reason", required=True, help="Blocked or failure reason")

    cancel_parser = subparsers.add_parser("cancel", help="Record a cancelled task and cancel mode")
    cancel_parser.add_argument("--task", type=int, required=True, help="Task number to cancel")
    cancel_parser.add_argument("--reason", required=True, help="Cancellation reason")

    return parser.parse_args()


def load_lines(roadmap_path: Path) -> list[str]:
    if not roadmap_path.exists():
        raise FileNotFoundError(f"ROADMAP.md not found: {roadmap_path}")
    return roadmap_path.read_text(encoding="utf-8").splitlines()


def save_lines(roadmap_path: Path, lines: list[str]) -> None:
    roadmap_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def section_bounds(lines: list[str], section: roadmap_state.Section) -> tuple[int, int]:
    start_index = section.start_line - 1
    end_index = len(lines)
    for idx in range(start_index + 1, len(lines)):
        if lines[idx].startswith("## "):
            end_index = idx
            break
    return start_index, end_index


def cleanup_meta(meta: str) -> str:
    cleaned = SUCCESS_RE.sub("", meta)
    cleaned = FAIL_RE.sub("", cleaned)
    cleaned = CANCEL_RE.sub("", cleaned)
    return cleaned.strip()


def resume_mode_for(section: roadmap_state.Section) -> str:
    mode_info = roadmap_state.parse_mode(section.mode)
    if mode_info["kind"] in {"중단", "취소"}:
        return mode_info["resume_mode"] or "대기 중"
    return mode_info["kind"] or "대기 중"


def stopped_mode_value(kind: str, section: roadmap_state.Section, reason: str) -> str:
    return f"{kind} [이전: {resume_mode_for(section)}] ({reason})"


def task_line_index(section: roadmap_state.Section, task_number: int) -> int:
    for task in section.tasks:
        if task.number == task_number:
            return task.line - 1
    raise ValueError(f"Task {task_number} not found in active roadmap section")


def mode_line_index(lines: list[str], start: int, end: int) -> int | None:
    for idx in range(start + 1, end):
        if roadmap_state.MODE_RE.match(lines[idx]):
            return idx
    return None


def progress_line_index(lines: list[str], start: int, end: int) -> int | None:
    for idx in range(start + 1, end):
        if roadmap_state.PROGRESS_RE.match(lines[idx]):
            return idx
    return None


def remove_active_markers(lines: list[str], start: int, end: int) -> list[str]:
    return lines[:start] + [line for line in lines[start:end] if not roadmap_state.ACTIVE_RE.match(line)] + lines[end:]


def update_progress(lines: list[str], section: roadmap_state.Section) -> list[str]:
    start, end = section_bounds(lines, section)
    checked = sum(1 for task in section.tasks if task.checked)
    total = len(section.tasks)
    percent = 0 if total == 0 else round((checked / total) * 100)
    progress_line = f"진행률: {checked}/{total} ({percent}%)"
    progress_idx = progress_line_index(lines, start, end)
    if progress_idx is not None:
        lines[progress_idx] = progress_line
    else:
        lines.insert(end, progress_line)
    return lines


def replace_task_line(line: str, checked: str, suffix: str) -> str:
    match = roadmap_state.TASK_RE.match(line)
    if not match:
        raise ValueError(f"Unsupported task line format: {line}")
    meta = cleanup_meta(match.group("meta") or "")
    updated = (
        f"- [{checked}] {match.group('number')}. {match.group('title').strip()} "
        f"({match.group('owner').strip()})"
    )
    if meta:
        updated += f" {meta}"
    if suffix:
        updated += f" {suffix}"
    return updated


def set_change_line(lines: list[str], task_idx: int, text: str) -> list[str]:
    change_line = f"  변경: {text}"
    next_idx = task_idx + 1
    if next_idx < len(lines) and lines[next_idx].startswith("  변경:"):
        lines[next_idx] = change_line
    else:
        lines.insert(next_idx, change_line)
    return lines


def insert_active_marker(lines: list[str], section: roadmap_state.Section, task_number: int) -> list[str]:
    task_idx = task_line_index(section, task_number)
    title = next(task.title for task in section.tasks if task.number == task_number)
    marker = f"🔄 진행 중: {task_number}. {title}"
    insert_at = task_idx + 1
    if insert_at < len(lines) and lines[insert_at].startswith("  변경:"):
        insert_at += 1
    lines.insert(insert_at, marker)
    return lines


def set_mode(lines: list[str], section: roadmap_state.Section, mode_value: str) -> list[str]:
    start, end = section_bounds(lines, section)
    idx = mode_line_index(lines, start, end)
    mode_line = f"모드: {mode_value}"
    if idx is not None:
        lines[idx] = mode_line
    else:
        lines.insert(start + 1, mode_line)
    return lines


def refresh_section(roadmap_path: Path) -> tuple[list[str], roadmap_state.Section]:
    lines = load_lines(roadmap_path)
    sections = roadmap_state.parse_tasks(lines)
    section = roadmap_state.choose_active_section(sections)
    if section is None:
        raise ValueError("No active workflow section found in ROADMAP.md")
    return lines, section


def run_start(roadmap_path: Path, task_number: int) -> None:
    lines, section = refresh_section(roadmap_path)
    start, end = section_bounds(lines, section)
    lines = remove_active_markers(lines, start, end)
    sections = roadmap_state.parse_tasks(lines)
    section = roadmap_state.choose_active_section(sections)
    if section is None:
        raise ValueError("No active workflow section found after removing markers")
    target = next((task for task in section.tasks if task.number == task_number), None)
    if target is None:
        raise ValueError(f"Task {task_number} not found in active roadmap section")
    if target.checked:
        raise ValueError(f"Task {task_number} is already completed")
    if target.cancelled:
        raise ValueError(f"Task {task_number} is cancelled")
    if target.failed:
        raise ValueError(f"Task {task_number} is marked failed and should be resumed explicitly")
    completed = {task.number for task in section.tasks if task.checked}
    unmet_dependencies = [dep for dep in target.blocked_by if dep not in completed]
    if unmet_dependencies:
        deps = ", ".join(str(dep) for dep in unmet_dependencies)
        raise ValueError(f"Task {task_number} is blocked by unfinished dependencies: {deps}")
    lines = insert_active_marker(lines, section, task_number)
    save_lines(roadmap_path, lines)


def run_complete(roadmap_path: Path, task_number: int, date: str, change: str, activate_next: bool) -> None:
    lines, section = refresh_section(roadmap_path)
    mode_info = roadmap_state.parse_mode(section.mode)
    start, end = section_bounds(lines, section)
    lines = remove_active_markers(lines, start, end)
    sections = roadmap_state.parse_tasks(lines)
    section = roadmap_state.choose_active_section(sections)
    if section is None:
        raise ValueError("No active workflow section found after removing markers")

    task_idx = task_line_index(section, task_number)
    lines[task_idx] = replace_task_line(lines[task_idx], "x", f"✅ {date}")
    lines = set_change_line(lines, task_idx, change)
    if mode_info["kind"] in {"중단", "취소"}:
        restored_mode = mode_info["resume_mode"] or ("자동진행" if activate_next else "대기 중")
        lines = set_mode(lines, section, restored_mode)

    sections = roadmap_state.parse_tasks(lines)
    section = roadmap_state.choose_active_section(sections)
    if section is None:
        raise ValueError("No active workflow section found after completion update")
    lines = update_progress(lines, section)
    save_lines(roadmap_path, lines)

    if activate_next:
        summary = roadmap_state.summarize(roadmap_path)
        next_task = summary.get("next_runnable_task")
        if next_task:
            run_start(roadmap_path, next_task["number"])


def run_block(roadmap_path: Path, task_number: int, reason: str) -> None:
    lines, section = refresh_section(roadmap_path)
    start, end = section_bounds(lines, section)
    lines = remove_active_markers(lines, start, end)
    sections = roadmap_state.parse_tasks(lines)
    section = roadmap_state.choose_active_section(sections)
    if section is None:
        raise ValueError("No active workflow section found after removing markers")

    task_idx = task_line_index(section, task_number)
    lines[task_idx] = replace_task_line(lines[task_idx], " ", f"❌ 실패 ({reason})")
    lines = set_mode(lines, section, stopped_mode_value("중단", section, reason))
    save_lines(roadmap_path, lines)


def run_cancel(roadmap_path: Path, task_number: int, reason: str) -> None:
    lines, section = refresh_section(roadmap_path)
    mode_info = roadmap_state.parse_mode(section.mode)
    start, end = section_bounds(lines, section)
    lines = remove_active_markers(lines, start, end)
    sections = roadmap_state.parse_tasks(lines)
    section = roadmap_state.choose_active_section(sections)
    if section is None:
        raise ValueError("No active workflow section found after removing markers")

    task_idx = task_line_index(section, task_number)
    lines[task_idx] = replace_task_line(lines[task_idx], " ", f"❌ 취소 ({reason})")
    if mode_info["kind"] in {"중단", "취소"}:
        lines = set_mode(lines, section, resume_mode_for(section))
    save_lines(roadmap_path, lines)


def main() -> int:
    args = parse_args()
    roadmap_path = roadmap_state.resolve_roadmap(args.path)

    if args.command == "start":
        run_start(roadmap_path, args.task)
    elif args.command == "complete":
        run_complete(roadmap_path, args.task, args.date, args.change, args.activate_next)
    elif args.command == "block":
        run_block(roadmap_path, args.task, args.reason)
    elif args.command == "cancel":
        run_cancel(roadmap_path, args.task, args.reason)
    else:
        raise ValueError(f"Unsupported command: {args.command}")

    summary = roadmap_state.summarize(roadmap_path)
    if args.json:
        json.dump(summary, sys.stdout, ensure_ascii=False, indent=2)
        sys.stdout.write("\n")
    else:
        roadmap_state.print_text(summary)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
