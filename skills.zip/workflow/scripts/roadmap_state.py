#!/usr/bin/env python3
"""Summarize ROADMAP.md workflow state for Codex workflow skills."""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, asdict
from pathlib import Path


TASK_RE = re.compile(
    r"^- \[(?P<checked>x| )\] (?P<number>\d+)\. (?P<title>.+?) \((?P<owner>[^)]+)\)(?P<meta>.*)$"
)
BLOCKED_RE = re.compile(r"\[blockedBy:\s*([0-9,\s]+)\]")
MODE_RE = re.compile(r"^모드:\s*(.+)$")
PROGRESS_RE = re.compile(r"^진행률:\s*(\d+)/(\d+)\s+\((\d+)%\)$")
ACTIVE_RE = re.compile(r"^🔄 진행 중:\s*(.+)$")
SECTION_RE = re.compile(r"^##\s+(.+)$")
CURRENT_TASK_RE = re.compile(r"^(?P<number>\d+)\.\s*(?P<title>.+)$")
TERMINAL_MODE_RE = re.compile(
    r"^(?P<kind>중단|취소)(?:\s+\[이전:\s*(?P<resume>[^\]]+)\])?(?:\s+\((?P<reason>.*)\))?$"
)
SECTION_PRIORITY_RULES = (
    ("현재 작업", 0),
    ("리팩토링 계획", 1),
    ("리뷰 발견사항", 2),
)


@dataclass
class Task:
    number: int
    title: str
    owner: str
    checked: bool
    failed: bool
    cancelled: bool
    blocked_by: list[int]
    line: int
    raw: str


@dataclass
class Section:
    title: str
    start_line: int
    mode: str | None
    progress: str | None
    active_marker: str | None
    tasks: list[Task]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Directory containing ROADMAP.md or a direct ROADMAP.md path",
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON output")
    return parser.parse_args()


def resolve_roadmap(path_value: str) -> Path:
    path = Path(path_value).expanduser().resolve()
    if path.is_file():
        return path
    return path / "ROADMAP.md"


def parse_mode(mode_value: str | None) -> dict[str, str | None]:
    if mode_value is None:
        return {"kind": None, "resume_mode": None, "reason": None, "raw": None}
    value = mode_value.strip()
    match = TERMINAL_MODE_RE.match(value)
    if match:
        return {
            "kind": match.group("kind"),
            "resume_mode": match.group("resume"),
            "reason": match.group("reason"),
            "raw": value,
        }
    return {"kind": value, "resume_mode": None, "reason": None, "raw": value}


def parse_tasks(lines: list[str]) -> list[Section]:
    sections: list[Section] = []
    current: Section | None = None

    for idx, raw_line in enumerate(lines, start=1):
        line = raw_line.rstrip("\n")
        section_match = SECTION_RE.match(line)
        if section_match:
            current = Section(
                title=section_match.group(1),
                start_line=idx,
                mode=None,
                progress=None,
                active_marker=None,
                tasks=[],
            )
            sections.append(current)
            continue

        if current is None:
            continue

        mode_match = MODE_RE.match(line)
        if mode_match:
            current.mode = mode_match.group(1).strip()
            continue

        progress_match = PROGRESS_RE.match(line)
        if progress_match:
            current.progress = line.strip()
            continue

        active_match = ACTIVE_RE.match(line)
        if active_match:
            current.active_marker = active_match.group(1).strip()
            continue

        task_match = TASK_RE.match(line)
        if task_match:
            blocked_match = BLOCKED_RE.search(task_match.group("meta") or "")
            blocked_by = []
            if blocked_match:
                blocked_by = [
                    int(part.strip())
                    for part in blocked_match.group(1).split(",")
                    if part.strip()
                ]
            current.tasks.append(
                Task(
                    number=int(task_match.group("number")),
                    title=task_match.group("title").strip(),
                    owner=task_match.group("owner").strip(),
                    checked=task_match.group("checked") == "x",
                    failed="❌ 실패" in (task_match.group("meta") or ""),
                    cancelled="❌ 취소" in (task_match.group("meta") or ""),
                    blocked_by=blocked_by,
                    line=idx,
                    raw=line,
                )
            )

    return sections


def section_priority(title: str) -> int:
    for prefix, priority in SECTION_PRIORITY_RULES:
        if title.startswith(prefix):
            return priority
    return len(SECTION_PRIORITY_RULES)


def section_sort_key(section: Section) -> tuple[int, int]:
    return (section_priority(section.title), section.start_line)


def has_live_unfinished_tasks(section: Section) -> bool:
    mode_info = parse_mode(section.mode)
    if mode_info["kind"] == "취소":
        return False
    return any(not task.checked and not task.cancelled for task in section.tasks)


def has_non_cancelled_unfinished_tasks(section: Section) -> bool:
    mode_info = parse_mode(section.mode)
    if mode_info["kind"] == "취소":
        return False
    return any(not task.checked for task in section.tasks)


def has_cancelled_unfinished_tasks(section: Section) -> bool:
    mode_info = parse_mode(section.mode)
    return mode_info["kind"] == "취소" and any(not task.checked for task in section.tasks)


def choose_active_section(sections: list[Section]) -> Section | None:
    active_sections = [section for section in sections if section.active_marker]
    if active_sections:
        return min(active_sections, key=section_sort_key)

    live_sections = [section for section in sections if has_live_unfinished_tasks(section)]
    if live_sections:
        return min(live_sections, key=section_sort_key)

    non_cancelled_unfinished = [
        section for section in sections if has_non_cancelled_unfinished_tasks(section)
    ]
    if non_cancelled_unfinished:
        return min(non_cancelled_unfinished, key=section_sort_key)

    cancelled_unfinished = [section for section in sections if has_cancelled_unfinished_tasks(section)]
    if cancelled_unfinished:
        return min(cancelled_unfinished, key=section_sort_key)

    for section in sections:
        if "현재 작업" in section.title and section.tasks:
            return section
    for section in sections:
        if section.tasks:
            return section
    for section in sections:
        if "현재 작업" in section.title:
            return section
    return sections[0] if sections else None


def task_has_change_line(lines: list[str], task: Task) -> bool:
    upper_bound = min(len(lines), task.line + 3)
    for idx in range(task.line, upper_bound):
        line = lines[idx]
        if line.startswith("  변경:"):
            return True
        if TASK_RE.match(line) or PROGRESS_RE.match(line) or SECTION_RE.match(line):
            break
    return False


def summarize(roadmap_path: Path) -> dict:
    if not roadmap_path.exists():
        return {
            "state": "no_roadmap",
            "roadmap_path": str(roadmap_path),
            "mode": None,
            "section_title": None,
            "progress": None,
            "active_marker": None,
            "active_task": None,
            "next_runnable_task": None,
            "tasks": [],
            "warnings": [],
            "runnable_task_numbers": [],
            "blocked_task_numbers": [],
            "cancelled_task_numbers": [],
            "closeout_needed": False,
            "missing_change_task_numbers": [],
        }

    lines = roadmap_path.read_text(encoding="utf-8").splitlines()
    sections = parse_tasks(lines)
    active_section = choose_active_section(sections)
    warnings: list[str] = []

    if active_section is None:
        return {
            "state": "empty_roadmap",
            "roadmap_path": str(roadmap_path),
            "mode": None,
            "section_title": None,
            "progress": None,
            "active_marker": None,
            "active_task": None,
            "next_runnable_task": None,
            "tasks": [],
            "warnings": ["No sections were found in ROADMAP.md"],
            "runnable_task_numbers": [],
            "blocked_task_numbers": [],
            "cancelled_task_numbers": [],
            "closeout_needed": False,
            "missing_change_task_numbers": [],
        }

    tasks = active_section.tasks
    completed = {task.number for task in tasks if task.checked}
    mode_info = parse_mode(active_section.mode)
    stopped_mode = mode_info["kind"] == "중단"
    cancelled_mode = mode_info["kind"] == "취소"
    failed_tasks = [task for task in tasks if not task.checked and task.failed and not task.cancelled]
    cancelled_tasks = [task for task in tasks if not task.checked and task.cancelled]
    missing_change_task_numbers = [
        task.number for task in tasks if task.checked and not task_has_change_line(lines, task)
    ]
    closeout_needed = bool(missing_change_task_numbers)
    runnable = [
        task
        for task in tasks
        if (
            not task.checked
            and not task.failed
            and not task.cancelled
            and set(task.blocked_by).issubset(completed)
        )
    ]
    blocked = [
        task
        for task in tasks
        if (
            not task.checked
            and not task.cancelled
            and (task.failed or not set(task.blocked_by).issubset(completed))
        )
    ]

    active_task = None
    if active_section.active_marker:
        active_task_match = CURRENT_TASK_RE.match(active_section.active_marker)
        if active_task_match:
            marker_number = int(active_task_match.group("number"))
            active_task = next((task for task in tasks if task.number == marker_number), None)
        else:
            warnings.append("Active marker does not match 'N. 작업명' format")

    if stopped_mode and active_task is None:
        active_task = failed_tasks[0] if failed_tasks else (runnable[0] if runnable else None)
    if cancelled_mode and active_task is None:
        active_task = cancelled_tasks[0] if cancelled_tasks else None

    next_runnable = None if stopped_mode or cancelled_mode else active_task or (runnable[0] if runnable else None)

    if any(not task.checked for task in tasks):
        if cancelled_mode:
            state = "cancelled"
        elif stopped_mode:
            state = "blocked"
        elif active_section.active_marker:
            state = "in_progress"
        elif runnable:
            state = "ready_to_run" if mode_info["kind"] == "자동진행" else "waiting_selection"
        elif cancelled_tasks and not blocked:
            state = "cancelled"
        else:
            state = "blocked"
    else:
        state = "complete"

    return {
        "state": state,
        "roadmap_path": str(roadmap_path),
        "mode": active_section.mode,
        "section_title": active_section.title,
        "progress": active_section.progress,
        "active_marker": active_section.active_marker,
        "active_task": asdict(active_task) if active_task else None,
        "next_runnable_task": asdict(next_runnable) if next_runnable else None,
        "tasks": [asdict(task) for task in tasks],
        "runnable_task_numbers": [task.number for task in runnable],
        "blocked_task_numbers": [task.number for task in blocked],
        "cancelled_task_numbers": [task.number for task in cancelled_tasks],
        "closeout_needed": closeout_needed,
        "missing_change_task_numbers": missing_change_task_numbers,
        "warnings": warnings,
    }


def print_text(summary: dict) -> None:
    def render_task(task: dict | None) -> str:
        if not task:
            return ""
        return f"{task['number']}. {task['title']} ({task['owner']})"

    print(f"state={summary['state']}")
    print(f"roadmap_path={summary['roadmap_path']}")
    print(f"section_title={summary['section_title'] or ''}")
    print(f"mode={summary['mode'] or ''}")
    print(f"progress={summary['progress'] or ''}")
    print(f"active_marker={summary['active_marker'] or ''}")
    print(f"active_task={render_task(summary['active_task'])}")
    print(f"next_runnable_task={render_task(summary['next_runnable_task'])}")
    print(
        "runnable_task_numbers="
        + ",".join(str(number) for number in summary.get("runnable_task_numbers", []))
    )
    print(
        "blocked_task_numbers="
        + ",".join(str(number) for number in summary.get("blocked_task_numbers", []))
    )
    print(
        "cancelled_task_numbers="
        + ",".join(str(number) for number in summary.get("cancelled_task_numbers", []))
    )
    print(f"closeout_needed={str(summary.get('closeout_needed', False)).lower()}")
    print(
        "missing_change_task_numbers="
        + ",".join(str(number) for number in summary.get("missing_change_task_numbers", []))
    )
    for warning in summary.get("warnings", []):
        print(f"warning={warning}")


def main() -> int:
    args = parse_args()
    roadmap_path = resolve_roadmap(args.path)
    summary = summarize(roadmap_path)
    if args.json:
        json.dump(summary, sys.stdout, ensure_ascii=False, indent=2)
        sys.stdout.write("\n")
    else:
        print_text(summary)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
