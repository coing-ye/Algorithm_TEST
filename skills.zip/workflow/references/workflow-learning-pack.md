# Workflow Learning Pack

이 문서는 현재 구현된 Codex용 `workflow` 스킬을 따라가면서 학습하기 위한 교육 자료다.

목표는 두 가지다.

1. 왜 이런 스킬이 필요한지 이해한다.
2. 실제로 `$workflow`를 써서 작은 프로젝트를 계획하고 실행할 수 있게 된다.

## 이 자료의 대상

- Codex를 처음 쓰지만 장기 작업 흐름을 만들고 싶은 사람
- Claude 스타일의 workflow를 Codex로 옮긴 이유를 이해하고 싶은 사람
- `ROADMAP.md`, `update_plan`, helper script가 어떻게 연결되는지 배우고 싶은 사람

## 추천 학습 순서

1. [ai-model-evolution-2024-2026.md](ai-model-evolution-2024-2026.md)
2. [workflow-reference.md](workflow-reference.md)
3. [SKILL.md](../SKILL.md)
4. `scripts/roadmap_state.py`
5. `scripts/roadmap_update.py`
6. `tests/test_roadmap_state.py`
7. `tests/test_roadmap_update.py`

## 먼저 이해해야 할 배경

최근 모델은 단순 채팅 모델이 아니라, 긴 작업을 이어가는 reasoning + tool-use + coding agent 방향으로 변했다.

이 변화 때문에 실제 개발에서는 아래가 중요해졌다.

- 작업 상태를 세션 밖에 저장하는 것
- 다음 할 일을 사람이 잊지 않도록 구조화하는 것
- 중단, 복구, 완료를 같은 형식으로 다루는 것
- 모델 능력보다 workflow 설계를 먼저 맞추는 것

현재 `workflow` 스킬은 이 문제를 Codex에 맞게 푼 로컬 운영 규약이다.

## 현재 구현된 workflow 스킬의 핵심 구조

### 1. 라우터 스킬

메인 엔트리는 [`workflow/SKILL.md`](../SKILL.md)다.

역할:

- 현재 작업 상태를 보고 어떤 phase로 갈지 결정한다.
- `ROADMAP.md`가 있으면 복구한다.
- 없으면 `init` 또는 `plan`으로 보낸다.
- 진행 중이면 `run`, 마무리면 `complete`, 어긋났으면 `sync`로 보낸다.

핵심 아이디어:

- `ROADMAP.md`는 세션 밖 상태 저장소다.
- `update_plan`은 현재 세션용 추적기다.
- 두 개를 맞춰 가며 작업한다.

### 2. phase 분리

구현된 companion skill은 다음과 같다.

- `workflow-init`
- `workflow-plan`
- `workflow-run`
- `workflow-complete`
- `workflow-sync`

이 분리는 교육적으로도 중요하다. "계획", "실행", "마무리", "정합성 복구"를 섞지 않게 해준다.

### 3. helper script

이 스킬의 실제 강점은 문서만이 아니라 helper script에 있다.

#### `scripts/roadmap_state.py`

역할:

- `ROADMAP.md`를 읽고 현재 상태를 기계적으로 요약한다.
- 예: `no_roadmap`, `waiting_selection`, `in_progress`, `blocked`, `complete`

왜 중요한가:

- 사람이 파일을 대충 읽고 오판하는 일을 줄인다.
- phase마다 같은 규칙으로 상태를 해석하게 해준다.

#### `scripts/roadmap_update.py`

역할:

- `ROADMAP.md`의 기계적 수정만 담당한다.
- 현재 구현된 동작:
  - `start`
  - `complete`
  - `block`

왜 중요한가:

- active marker, 진행률, `변경:` 라인을 수작업으로 맞추는 실수를 줄인다.

### 4. 테스트

`tests/`에 자동 테스트가 있다.

- `test_roadmap_state.py`
  - 상태 판별 검증
- `test_roadmap_update.py`
  - 기계적 갱신 검증

교육적으로 중요한 포인트는 "문서형 workflow라도 테스트 가능한 핵심을 분리해 두면 안정성이 크게 올라간다"는 점이다.

## 이 스킬이 해결하는 문제

### 문제 1. 세션이 끊기면 맥락이 사라진다

해결:

- `ROADMAP.md`에 현재 작업을 남긴다.
- `🔄 진행 중`, `모드:`, `진행률:`로 복구한다.

### 문제 2. 모델이 지금 뭘 해야 하는지 자꾸 흔들린다

해결:

- 체크리스트 순서와 `blockedBy`로 다음 작업을 고정한다.

### 문제 3. 완료 처리와 중단 처리가 들쭉날쭉하다

해결:

- `complete`와 `block` 흐름을 문서와 helper로 표준화한다.

### 문제 4. Claude와 Codex의 기능 차이가 크다

해결:

- Claude 전용 개념은 의도만 유지하고 Codex 도구로 치환한다.
  - `TaskList` -> `ROADMAP.md` + `update_plan`
  - `AskUserQuestion` -> 짧은 plain-text 질문
  - task metadata -> markdown 규약 + helper script

## 이 스킬의 장점

- Codex에서 실제로 굴러간다.
- 세션 복구가 된다.
- phase 구분이 명확하다.
- helper와 테스트가 있어서 반복 사용에 강하다.
- Claude의 의도를 버리지 않고 Codex 제약에 맞춰 현실적으로 바꿨다.

## 이 스킬의 현재 한계

### 1. subagent는 기본값이 아니다

- 현재는 direct execution이 기본이다.
- 사용자가 명시적으로 원할 때만 delegation을 쓰게 되어 있다.
- 즉, "subagent 지원"은 있지만 "subagent 중심 orchestration"은 아니다.

### 2. 상태 모델이 아직 완전히 닫히지 않았다

- 문서에는 `cancelled`가 있지만 helper 반자동화는 아직 부족하다.
- `resume` 류의 보강도 더 들어갈 수 있다.

### 3. closeout completeness detection은 더 정교해질 수 있다

- 현재 parser는 핵심 상태는 잘 잡지만, "완료됐지만 마감 요약이 빠진 상태"까지 별도 state로 다루진 않는다.

## 왜 이 구조가 교육적으로 좋은가

이 스킬은 초보자에게도 아래 순서로 사고하게 만든다.

1. 지금 상태가 무엇인가
2. 다음 작업은 무엇인가
3. 작업을 어떤 파일로 실행할 것인가
4. 검증은 무엇인가
5. 완료 후 무엇을 기록해야 하는가

즉, 단순히 AI에게 "만들어줘"라고 던지는 대신, 작업을 재현 가능한 형태로 구조화하는 연습이 된다.

## 따라하기 실습

### 실습 1. 새 프로젝트 부트스트랩

상황:

- `ROADMAP.md` 없음
- manifest 없음
- 교육용 작은 프로젝트를 새로 만들고 싶음

기대 동작:

- `workflow`가 환경 질문을 먼저 한다.
- 예: Node.js CLI / React 웹앱 / Python 스크립트
- 답을 받으면 `workflow-plan` 성격으로 첫 `ROADMAP.md`를 만든다.

학습 포인트:

- 왜 환경 질문을 먼저 해야 하는가
- 왜 계획 없이 바로 파일부터 만들면 나중에 흔들리는가

### 실습 2. 진행 중 작업 복구

상황:

- `ROADMAP.md` 존재
- `🔄 진행 중` 마커 존재
- 다음 세션에서 이어서 작업해야 함

기대 동작:

- `roadmap_state.py`가 `in_progress`를 읽는다.
- `workflow-run`이 현재 task를 복구한다.

학습 포인트:

- durable state와 in-session state의 차이
- 왜 `ROADMAP.md`를 먼저 읽는가

### 실습 3. blocker 처리

상황:

- 구현 중 타입 충돌 또는 외부 의존성 문제 발생

기대 동작:

- `workflow-sync` 또는 `workflow-run` closeout에서 `block` 처리
- `모드: 중단 (...)`
- task line에 `❌ 실패 (...)`

학습 포인트:

- 실패를 숨기지 않고 구조화된 상태로 남기는 법
- 다음 세션에서 같은 곳을 어떻게 다시 잡는가

## 읽으면서 같이 보면 좋은 파일

- 메인 라우터: [`/Users/sswoo/.codex/skills/workflow/SKILL.md`](/Users/sswoo/.codex/skills/workflow/SKILL.md)
- 상세 규약: [`/Users/sswoo/.codex/skills/workflow/references/workflow-reference.md`](/Users/sswoo/.codex/skills/workflow/references/workflow-reference.md)
- 상태 파서: [`/Users/sswoo/.codex/skills/workflow/scripts/roadmap_state.py`](/Users/sswoo/.codex/skills/workflow/scripts/roadmap_state.py)
- 상태 갱신기: [`/Users/sswoo/.codex/skills/workflow/scripts/roadmap_update.py`](/Users/sswoo/.codex/skills/workflow/scripts/roadmap_update.py)
- 상태 테스트: [`/Users/sswoo/.codex/skills/workflow/tests/test_roadmap_state.py`](/Users/sswoo/.codex/skills/workflow/tests/test_roadmap_state.py)
- 갱신 테스트: [`/Users/sswoo/.codex/skills/workflow/tests/test_roadmap_update.py`](/Users/sswoo/.codex/skills/workflow/tests/test_roadmap_update.py)

## 학습 체크리스트

- `ROADMAP.md`의 역할을 설명할 수 있다.
- `update_plan`과 `ROADMAP.md`의 차이를 설명할 수 있다.
- `waiting_selection`과 `in_progress`의 차이를 설명할 수 있다.
- `block`이 왜 필요한지 설명할 수 있다.
- Claude workflow와 Codex workflow의 차이를 설명할 수 있다.
- 왜 이 스킬이 "모델 성능"보다 "운영 규약"에 더 가깝다고 말하는지 설명할 수 있다.

## 수업 운영안 예시

### 60분 버전

1. 10분: AI 모델 변화 요약
2. 15분: `workflow` 아키텍처 설명
3. 15분: `ROADMAP.md` 읽기 실습
4. 10분: helper script 시연
5. 10분: blocker와 closeout 토론

### 90분 버전

1. 20분: 최근 2년 모델 변화
2. 20분: Claude vs Codex workflow 차이
3. 20분: `ROADMAP.md` 작성 실습
4. 15분: `roadmap_state.py` / `roadmap_update.py` 읽기
5. 15분: 작은 프로젝트에 실제 적용

## 다음에 추가하면 좋은 자료

- `workflow`용 예시 `ROADMAP.md` 모음
- subagent 위임 템플릿 모음
- `cancel/resume`이 추가된 뒤의 심화 문서
- "나쁜 roadmap"과 "좋은 roadmap" 비교 자료

## 함께 보면 좋은 공식 자료

- AI 모델 흐름 요약: [ai-model-evolution-2024-2026.md](ai-model-evolution-2024-2026.md)
- OpenAI Codex 소개:
  - https://openai.com/index/introducing-codex/
- Anthropic Claude Sonnet announcements:
  - https://www.anthropic.com/claude/sonnet
- Google Gemini 2.0:
  - https://blog.google/innovation-and-ai/models-and-research/google-deepmind/google-gemini-ai-update-december-2024/
