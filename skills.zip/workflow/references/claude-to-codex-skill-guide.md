# Claude to Codex Skill Guide

이 문서는 현재 완료된 Claude Code 스킬 `workflow`, `team-refactor`, `team-review`의 의도를 Codex 기준으로 다시 정리한 가이드다.

목표는 두 가지다.

1. 각 Claude 스킬이 원래 무엇을 하려던 것인지 빠르게 이해한다.
2. Codex에서는 무엇이 가능하고, 무엇은 방식이 달라지는지 구분한 뒤 실제로 사용할 수 있게 한다.

## 먼저 결론

Codex에서는 Claude처럼 `/workflow`, `/team-refactor`, `/team-review`를 slash command로 쓰는 것이 아니라, 명시적 skill 호출인 아래 형태로 쓰는 것이 기준이다.

- `$workflow`
- `$team-refactor`
- `$team-review`

또한 Codex에서는 다음을 기대하면 안 된다.

- Claude의 `TaskList`, `TaskCreate`, `TaskUpdate`
- `AskUserQuestion` 메뉴 UI
- hidden task metadata
- hook 기반 자동 라우팅
- Agent Team lifecycle을 제품이 자동으로 관리해 주는 것

대신 Codex에서는 아래를 중심으로 동작한다.

- `ROADMAP.md`
- `update_plan`
- `spawn_agent`
- 짧은 plain-text 질문
- 로컬 helper script와 검증 명령

## 1. `workflow`의 원래 의도와 Codex 변환

### Claude 쪽 의도

원본 `workflow`는 라우터다.

- 요청과 현재 상태를 보고 phase를 선택한다.
- `workflow-init`, `workflow-plan`, `workflow-execute`, `workflow-complete`로 분기한다.
- 세션 내 상태는 `TaskList`, 세션 간 상태는 `ROADMAP.md`로 다룬다.
- 작업 선택은 `AskUserQuestion`으로 처리한다.

### Codex에서 구현 가능한 핵심

현재 Codex 변환본은 이 의도를 이렇게 옮긴다.

- 라우터는 유지한다.
- 세션 간 상태는 `ROADMAP.md`가 맡는다.
- 세션 내 상태는 `update_plan`이 맡는다.
- phase는 `workflow-init`, `workflow-plan`, `workflow-run`, `workflow-complete`, `workflow-sync`로 나뉜다.
- 질문은 menu widget 대신 plain-text 한 문장으로 묻는다.

### Codex에서 바뀐 점

- `TaskList` 복구가 아니라 `ROADMAP.md` 파싱이 중심이다.
- 자동 orchestration보다 문서형 state machine에 가깝다.
- 리뷰, 커밋, PR, push는 기본 workflow의 일부가 아니라 opt-in 후속 동작이다.

### 언제 쓰면 좋은가

- 여러 단계 작업을 끊어서 이어서 해야 할 때
- `ROADMAP.md`를 기반으로 상태를 복구하고 싶을 때
- auto mode와 selection mode를 번갈아 쓰고 싶을 때

### 실제 호출 예시

- `$workflow 이 저장소에서 다음 작업부터 이어서 진행해줘`
- `$workflow 이 기능을 먼저 계획부터 세워줘`
- `$workflow auto mode로 끝까지 가능한 데까지 진행해줘`

## 2. `team-refactor`의 원래 의도와 Codex 변환

### Claude 쪽 의도

원본 `team-refactor`는 다관점 병렬 리팩토링 에이전트다.

- 구조, 의존성, 테스트 영향, 아키텍처 관점에서 동시에 분석한다.
- 분석 결과를 종합해 실행 계획을 만든다.
- 사용자 승인 후 병렬 실행한다.
- 결과를 `ROADMAP.md`와 `/workflow`에 연결한다.

### Codex에서 구현 가능한 핵심

현재 Codex 변환본은 이 의도를 이렇게 옮긴다.

- 분석 단계는 `explorer` subagent 병렬 실행으로 대체한다.
- 실행 단계는 `worker` subagent로 대체한다.
- 승인 게이트는 one-shot plain-text 질문으로 처리한다.
- worktree 격리 대신 disjoint write scope를 명시한다.
- 결과는 필요 시 `ROADMAP.md`의 `## 리팩토링 계획` 섹션으로 남긴다.

### Codex에서 바뀐 점

- Agent Team 제품 기능 대신 `spawn_agent` 조합으로 구현한다.
- worker는 명시적 파일 ownership이 있어야 한다.
- 승인 전에는 분석만 하고, 승인 후에만 실행한다.
- 큰 리팩토링은 `$workflow-plan`이 직접 모두 책임지기보다 `$team-refactor`를 추천할 수 있다.

### 언제 쓰면 좋은가

- 리팩토링 범위가 크고, 파일이 여러 개 걸릴 때
- "어떻게 쪼개야 하는지"부터 다관점 분석이 필요할 때
- 겹치지 않는 파일 묶음으로 병렬 실행이 가능할 때

### 실제 호출 예시

- `$team-refactor src/auth`
- `$team-refactor src/auth "인증 서비스 책임을 분리하고 테스트 영향까지 봐줘"`
- `$team-refactor app/services "의존성 꼬인 부분을 분석하고 실행 계획까지 세워줘"`

### 사용 순서

1. 대상이나 목표를 준다.
2. Codex가 다관점 분석과 제안 목록을 만든다.
3. `전부 실행 / 일부만 실행 / 계획만 유지` 중 하나를 고른다.
4. 승인 시에만 worker가 실제 수정을 진행한다.
5. 필요하면 이후 `$workflow`로 이어서 남은 작업을 수행한다.

## 3. `team-review`의 원래 의도와 Codex 변환

### Claude 쪽 의도

원본 `team-review`는 다관점 병렬 코드 리뷰다.

- PR, 커밋 범위, 파일 변경을 여러 관점에서 동시에 본다.
- 보안, 성능, 정확성, 아키텍처 발견을 교차 검증한다.
- 결과를 ROADMAP과 연결할 수 있다.

### Codex에서 구현 가능한 핵심

현재 Codex 변환본은 이 의도를 이렇게 옮긴다.

- review 대상은 PR 번호, 경로, commit range, `git diff HEAD`로 받는다.
- 리뷰어는 `explorer` subagent로 병렬 실행한다.
- lead가 Critical 이슈를 로컬에서 다시 확인하고 종합한다.
- 최종 출력은 Codex 기본 리뷰 스타일인 `findings first`를 따른다.
- 필요하면 `ROADMAP.md`에 `## 리뷰 발견사항`을 기록할 수 있다.

### Codex에서 바뀐 점

- PR metadata를 제품이 자동 주입해주지 않는다.
- `gh`가 없거나 PR 정보가 로컬에 없으면 그 범위만큼만 리뷰한다.
- hook이나 shutdown 절차보다 lead synthesis가 더 중요하다.
- 리뷰는 자동 후처리가 아니라 명시적 follow-up이다.

### 언제 쓰면 좋은가

- 큰 변경 후 2차 검토가 필요할 때
- 보안, auth, payment, migration, shared infra 같은 위험도가 높은 변경일 때
- refactor 후 회귀 리스크를 별도 시각에서 보고 싶을 때

### 실제 호출 예시

- `$team-review`
- `$team-review HEAD~3..HEAD`
- `$team-review src/auth`
- `$team-review #142`

## 4. 세 스킬을 같이 쓰는 추천 패턴

### 패턴 A: 일반 기능 개발

1. `$workflow`로 roadmap 생성 또는 복구
2. `$workflow`로 구현 진행
3. 필요하면 `$team-review`

추천 상황:

- 대부분의 일반 기능 개발
- 단계 분리가 중요한 작업

### 패턴 B: 큰 리팩토링

1. `$team-refactor`로 다관점 분석
2. 승인 후 일부 또는 전체 실행
3. 남은 작업은 `$workflow`로 이어서 관리
4. 마무리 전 `$team-review`

추천 상황:

- 구조가 얽혀 있고 한 번에 건드릴 파일이 많은 작업

### 패턴 C: 구현은 끝났고 검토만 필요

1. `$team-review`
2. 발견사항이 있으면 `ROADMAP.md`에 기록하거나 `$workflow`로 수정

추천 상황:

- 이미 수정은 끝났고 리뷰 신뢰도만 더 필요할 때

## 5. 현재 기준 권장 운영 규칙

- 기본은 `$workflow`
  - 상태 관리와 연속 작업의 중심축이다.
- 리팩토링이 크면 `$team-refactor`
  - workflow가 이걸 자동으로 숨겨서 돌리지는 않는다.
- 큰 변경 후 검토가 필요하면 `$team-review`
  - 역시 자동이 아니라 명시적 follow-up이다.

즉, 실무적으로는 이렇게 생각하면 된다.

- `workflow` = 운영 축
- `team-refactor` = 큰 구조 변경의 분석/실행 보조 축
- `team-review` = 고위험 변경의 검토 축

## 6. 현재 Codex 변환의 한계

- Claude 수준의 built-in phase router와 task graph는 없다.
- 질문은 richer UI가 아니라 plain-text다.
- Agent lifecycle은 제품이 아니라 lead prompt와 `spawn_agent` 운용으로 만든다.
- 자동 PR 연동, hook, hidden state는 기대하면 안 된다.

하지만 아래는 충분히 된다.

- 명시적 skill 호출
- `ROADMAP.md` 기반 durable state
- 병렬 분석과 병렬 실행
- 결과를 workflow에 다시 연결하는 것

## 7. 가장 간단한 실사용 시작점

작업 종류에 따라 아래 세 개만 기억하면 된다.

- 새 작업 시작 또는 이어서 하기:
  - `$workflow`
- 큰 리팩토링을 구조적으로 풀기:
  - `$team-refactor`
- 변경 후 다관점 리뷰:
  - `$team-review`

## 관련 파일

- `workflow`: [../SKILL.md](../SKILL.md)
- `workflow reference`: [workflow-reference.md](workflow-reference.md)
- `team-review`: [/Users/sswoo/.codex/skills/team-review/SKILL.md](/Users/sswoo/.codex/skills/team-review/SKILL.md)
- `team-refactor`: [/Users/sswoo/.codex/skills/team-refactor/SKILL.md](/Users/sswoo/.codex/skills/team-refactor/SKILL.md)
