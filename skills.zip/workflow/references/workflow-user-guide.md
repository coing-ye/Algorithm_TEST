# Workflow User Guide

Use this guide when you want the short, practical answer to "what should I type?"

## Remember Only Four Commands

- `$workflow`
- `$team-refactor`
- `$team-debug`
- `$team-review`

Most users should start with those four. The narrower phase skills exist for advanced control, not for normal day-to-day entry.

## Typical Usage

### 1. Start or continue ordinary multi-step work

Use:

```text
$workflow 로그인 API와 테스트까지 진행해줘.
```

Or, when a roadmap already exists:

```text
$workflow 이어서 진행해줘.
```

What happens:

- Codex reads `ROADMAP.md` first if it exists.
- If no roadmap exists and the work is multi-step, Codex creates one.
- If a roadmap already exists, Codex restores the next runnable task.
- If this is a brand-new feature with important design choices, Codex may ask one short design question before writing the roadmap.

### 2. Bootstrapping a greenfield project

Use:

```text
$workflow 팀 프로젝트 현황을 보여주는 대시보드 웹앱을 만들어줘.
```

If the stack is not obvious, Codex may ask one short question such as:

```text
어떤 환경으로 시작할까요? Node.js CLI, React 웹앱, Python 스크립트 중 하나로 정하면 ROADMAP을 만들겠습니다.
```

### 3. Large refactor

Use:

```text
$team-refactor src/auth 책임을 분리하고 의존성을 정리해줘.
```

Use this when:

- the work is mostly refactoring
- multiple files or modules are involved
- you want a plan before execution

### 4. Review after important changes

Use:

```text
$team-review HEAD~3..HEAD
```

Or:

```text
$team-review src/auth
```

Use this when:

- you changed auth, security, billing, schema, or shared infrastructure
- you want a second pass before handoff
- a refactor landed and you want confidence

### 5. Ambiguous bug or hard debugging

Use:

```text
$team-debug 결제 완료 후 간헐적으로 중복 청구가 발생하는 원인을 찾아서 필요하면 수정까지 진행해줘.
```

Use this when:

- the bug is intermittent or hard to reproduce
- logs, state, and code paths point at different subsystems
- you want a root-cause-first investigation instead of serial guesswork
- you do not have the exact file yet, but there is a failing test, stack trace, or clear symptom to start from

## What `$workflow` Will Usually Do

`$workflow` is the router. It will usually choose one of these internal phases:

- recover state
- plan or refresh `ROADMAP.md`
- run the next task
- close out the current task
- sync roadmap drift after manual work
- recommend `$team-debug` when debugging becomes the real problem shape
- defer non-security review suggestions until the end when auto mode is still actively moving

You usually do not need to call those phase skills directly.

## When To Call A Phase Skill Directly

Call the narrower phase only when you explicitly want that behavior:

- `$workflow-plan`: write or refresh the roadmap without running the whole router
- `$workflow-run`: force the next runnable task to execute now
- `$workflow-complete`: close out a task after you already did the work
- `$workflow-sync`: reconcile roadmap drift after manual edits, review, or tests

## ROADMAP Expectations

The workflow works best when `ROADMAP.md` keeps:

- one active section such as `## 현재 작업 (YYYY-MM-DD)`
- `모드: 자동진행`, `모드: 개별선택`, or `모드: 대기 중`
- numbered checklist items
- `진행률:`
- `변경:` notes after completed tasks

If you already have a roadmap, keep it. `$workflow` is designed to recover from it rather than replace it.

## Good Cases For This Workflow

- work that spans multiple steps
- work that may continue across sessions
- tasks where recovery matters
- changes that benefit from review or refactor branching

## Skip The Workflow For These Cases

- tiny one-file fixes
- one-shot questions
- quick content generation
- tasks that clearly finish in a single step

For those, it is usually faster to just ask Codex directly.

## Practical Examples

```text
$workflow 이 저장소 구조를 분석하고 다음 작업부터 진행해줘.
$workflow ROADMAP 기준으로 자동진행 모드로 끝까지 진행해줘.
$team-refactor src/payments 모듈 경계를 다시 잡아줘.
$team-debug 로그인 후 10분쯤 지나면 세션이 끊기는 원인을 찾아줘.
$team-review HEAD
```

## Mental Model

Use this rule of thumb:

- ordinary work -> `$workflow`
- big refactor -> `$team-refactor`
- ambiguous bug -> `$team-debug`
- second-pass confidence -> `$team-review`
