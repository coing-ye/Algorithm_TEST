# Workflow Reference

Use this file for the detailed rules behind `$workflow`.

## Invocation Examples

- `Use $workflow to restore the roadmap in this repo and continue the next task.`
- `Use $workflow to plan this feature before coding.`
- `Use $workflow in auto mode to keep going until the roadmap is complete.`

## Codex Scope

This workflow is repository-first and Codex-native. It does not depend on hidden product metadata or Claude-specific task primitives such as `TaskList`, `TaskCreate`, `TaskUpdate`, `AskUserQuestion`, and tool hooks.

Codex should preserve the intent with these substitutes:

- `ROADMAP.md` instead of Claude task objects for durable state
- `update_plan` instead of Claude task lists for in-session status
- one concise plain-text question instead of `AskUserQuestion`
- one concise plain-text environment question when bootstrapping a roadmap-less greenfield project with no detectable stack
- direct execution by the main Codex session unless the user explicitly asks for delegation
- `scripts/roadmap_state.py` for deterministic roadmap parsing across phases

Optional adjacent skills:

- `$team-refactor` for large refactor analysis or approved parallel refactor execution
- `$team-debug` for ambiguous or cross-module root-cause debugging
- `$team-review` for explicit multi-angle review after meaningful changes

Normal usage should start from `$workflow`, `$team-refactor`, `$team-debug`, or `$team-review`. The narrower `$workflow-init`, `$workflow-plan`, `$workflow-run`, `$workflow-complete`, and `$workflow-sync` skills are internal or advanced phase entrypoints.

## Unsupported Or Opt-In Behavior

- No native task graph, menu widget, or hook automation is available through this skill.
- No hidden PR metadata or `--from-pr` style context import should be assumed.
- No automatic review, commit, push, or PR lifecycle is part of the core workflow.
- No default subagent orchestration should happen for ordinary single-threaded work.
- `$team-refactor`, `$team-debug`, and `$team-review` are opt-in adjuncts, not implicit workflow side effects.
- When escalation is needed for installs, network access, or unsandboxed commands, request approval explicitly.

## Recommended Helper

Use this helper before manual roadmap reasoning when possible:

```bash
python3 /path/to/workflow/scripts/roadmap_state.py . --json
```

Pay attention to:

- `state`
- `section_title`
- `next_runnable_task`
- `closeout_needed`
- `missing_change_task_numbers`

Within the skill folders, resolve it relative to the `workflow/` skill directory.

Use this helper when the roadmap state is known and the edit should be mechanical:

```bash
python3 /path/to/workflow/scripts/roadmap_update.py . start --task 2
python3 /path/to/workflow/scripts/roadmap_update.py . complete --task 2 --date 2026-03-19 --change "src/index.js (기능 구현)"
python3 /path/to/workflow/scripts/roadmap_update.py . block --task 2 --reason "타입 충돌"
python3 /path/to/workflow/scripts/roadmap_update.py . cancel --task 2 --reason "요구사항 변경"
```

`block` preserves the prior section mode as resume metadata. `cancel` is task-scoped by default and should not stop unrelated runnable tasks. Use section-level `모드: 취소 (...)` only when abandoning the whole active section.

## Recovery Heuristics

`ROADMAP.md` is the durable source of truth across sessions.

When no roadmap exists yet:

1. Inspect nearby manifests and entrypoints before asking the user anything.
2. Treat files such as `package.json`, `pyproject.toml`, `Cargo.toml`, `go.mod`, and `Gemfile` as stack hints.
3. If the request is greenfield and no stack can be inferred, ask one short environment question before writing the first roadmap.
4. Keep that question plain text because Codex does not provide Claude's question widget here.
5. If the user mentions a PR, review, or branch, inspect the local git state that actually exists here or ask for missing context instead of assuming hidden metadata.
6. If there is no roadmap and no concrete request, use `git status --short`, `git log --oneline -5`, and nearby `TODO` or `FIXME` markers to suggest the next likely action instead of giving generic advice.

Example:

```text
새 프로젝트라면 어떤 환경으로 시작할까요? Node.js CLI, React 웹앱, Python 스크립트 중 하나로 정하면 그 기준으로 ROADMAP을 만들겠습니다.
```

When a roadmap exists:

1. Read the file before planning new work.
2. Search for all of the following:
   - `🔄 진행 중`
   - unchecked task lines such as `- [ ]`
   - `모드:`
   - `진행률:`
3. Prefer the unfinished section with the highest workflow priority:
   - `## 현재 작업`
   - `## 리팩토링 계획`
   - `## 리뷰 발견사항`
   - other `##` sections
4. If both a `🔄 진행 중` marker and unchecked tasks exist, prefer the explicit `🔄 진행 중` marker as the current task.
5. If the roadmap contains only completed tasks, do not silently reopen work.
6. If the roadmap is complete but `closeout_needed=true`, finish the bookkeeping before treating the workflow as fully done.
7. If the roadmap is corrupt or unreadable and the repository has git history, try `git show HEAD:ROADMAP.md` and then recent ROADMAP history before falling back to manual recovery.
8. Preserve an existing `## 전략 설정` section as durable execution context.

Recommended search:

```bash
rg -n "🔄 진행 중|^- \\[ \\]|^모드:|^진행률:" ROADMAP.md
```

## Codex Phase Mapping

### Phase 0: Recover

- Detect the workspace root from git or the current working directory.
- Restore the active task from `ROADMAP.md` when unfinished work exists.
- Trust the roadmap over ephemeral session memory.
- Codex equivalent skill: `$workflow-init`

### Phase 1: Analyze

- Read manifests, README, existing roadmap, tests, and the files closest to the request.
- If no roadmap exists and the request is for a new project, infer the environment from manifests before asking the user.
- Use one concise blocking question only when the decision changes a public contract or major design.

### Phase 2: Plan

- Create or refresh `ROADMAP.md` for multi-step work.
- If this is the first roadmap for a greenfield request and the environment is still ambiguous, ask one short stack-selection question first.
- If this is a genuinely new feature with no roadmap and no nearby design notes, prefer one concise design-check question before writing a speculative roadmap.
- If the request is a broad refactor and the user wants multi-perspective analysis, recommend `$team-refactor` before locking in the execution plan.
- Keep the plan dependency-ordered.
- Usually produce 3-5 tasks.
- When needed, record durable design decisions in `## 설계 결정`.
- For bug work that may escalate later, record durable hints in `## Task Briefs`, for example `실행전략: team-debug-branch` or `복잡도태그: [complex-bug]`.

### Phase 3: Select

- If `모드: 자동진행`, continue automatically with the next unblocked task.
- If `모드: 개별선택` or `모드: 대기 중`, recommend the next task and ask a short plain-text question only when selection matters.
- Codex equivalent is a direct question, not a menu widget.

### Phase 4: Execute

- In Codex, default to direct execution.
- Only delegate when the user explicitly asks for subagents or parallel agent work.
- Prefer the simplest strategy that matches reality:
  - `local-direct`
  - `parallel-ok`
  - `refactor-branch`
  - `root-cause-debug`
  - `team-debug-branch`
- Keep the session plan in sync with the roadmap.
- Remember that `update_plan` supports only `pending`, `in_progress`, and `completed`; represent `blocked` or `cancelled` states in `ROADMAP.md` rather than inventing unsupported plan states.
- If verification needs installs, network access, or unsandboxed commands, request escalation rather than silently downgrading the checks.
- Codex equivalent skill: `$workflow-run`

### Phase 4.5: Sync

- When reconciling after work, detect the workspace root the same way: prefer git and fall back to the current working directory.
- Read `git status --short` only when inside a repository.
- If a task is blocked or cancelled, leave the session plan step `pending` and write the true state into `ROADMAP.md`.
- Codex equivalent skill: `$workflow-sync`

### Phase 5: Complete

- Mark the task complete.
- Record `변경:` on the next line with the key files and one-line summaries.
- Recalculate `진행률:`.
- Use concrete review triggers for follow-up confidence:
  - roughly 5+ files or 200+ changed lines
  - security/auth/payments/schema/shared infra paths
  - new directories or new module entrypoints
- In automatic mode, defer non-security review prompts until a natural stopping point or full completion. Security-sensitive changes can still justify an immediate review suggestion.
- Keep review, commit, push, and PR steps as explicit follow-up actions rather than automatic closeout side effects.
- When the change is security-sensitive, architecture-heavy, or broadly cross-cutting, suggest `$team-review` as an explicit confidence-increasing follow-up.
- Codex equivalent skill: `$workflow-complete`

### Phase 6: Next

- If more unblocked tasks remain and the mode is automatic, continue.
- Otherwise summarize status and ask for the next decision only if needed.

## Adjacent Skill Triggers

Use these as explicit recommendations, not silent background automation.

### Recommend `$team-refactor` when

- the request is primarily a refactor
- the scope spans many files or multiple module boundaries
- the user wants multiple refactor options or a coordinated parallel plan
- disjoint file ownership would make worker execution safer than ad-hoc delegation

### Recommend `$team-debug` when

- the request is primarily debugging rather than feature work
- the failure is intermittent, stateful, concurrency-related, or spread across multiple modules
- a normal root-cause pass keeps surfacing competing hypotheses
- the same bug area already has prior failed attempts or failure notes in the roadmap
- the user explicitly wants parallel or multi-angle debugging

### Recommend `$team-review` when

- the user explicitly asks for review
- the completed change touched security, auth, payment, migration, or shared infrastructure paths
- the task was a broad refactor and a second-pass review would materially reduce risk
- the user wants a higher-confidence signoff before commit or handoff

## ROADMAP Contract

Recommended shape:

```md
# ROADMAP

## Working Context
요청: 사용자 요청 한 줄 요약
전역 제약:
- 기존 공개 API 유지
- 빌드/테스트 명령 준수
공통 검증:
- pnpm tsc --noEmit
- pnpm test

## 현재 작업 (2026-03-18)
모드: 개별선택
- [ ] 1. 현재 구조와 제약 분석 (codex)
- [ ] 2. 구현 계획 정리 (codex) [blockedBy: 1]
- [ ] 3. 코드 수정 및 검증 (codex) [blockedBy: 2]
진행률: 0/3 (0%)

## Task Briefs
### 1. 현재 구조와 제약 분석
참조: README.md, package.json
대상 파일: src/, tests/
요구사항: 현재 구조와 관련 제약을 파악
인터페이스: public API, schema, config
제약사항: 기존 사용자 변경사항 덮어쓰기 금지
완료조건: 영향 범위와 검증 명령이 명확해짐

### 2. 간헐적 버그 조사
참조: failing test, stack trace, 최근 변경 파일
대상 파일: src/auth/, tests/auth/
요구사항: 재현 조건과 근본 원인 확인
실행전략: team-debug-branch
복잡도태그: [complex-bug]
완료조건: leading hypothesis와 확인용 검증 명령이 명확해짐
```

Checklist rules:

- Active unchecked checklist items should live only under `## 현재 작업`.
- Keep lines in the form `- [ ] N. 작업명 (owner)`.
- Put `모드:` immediately below the active section header.
- Keep `진행률:` as the last line of the active checklist section.
- Put detailed instructions in prose sections such as `## Task Briefs`.

Owner rules:

- For new Codex-generated items, default to `(codex)`.
- If an existing roadmap already uses `(impl-sonnet)` or other Claude-era labels, preserve them as hints for continuity.

## Completion Format

Use this format when closing a task:

```md
- [x] 2. 구현 계획 정리 (codex) ✅ 2026-03-18
  변경: ROADMAP.md (작업 구조와 실행 규칙 갱신)
```

If work is actively underway and the roadmap style already uses explicit markers, it is acceptable to add a nearby line such as:

```md
🔄 진행 중: 3. 코드 수정 및 검증
```

Remove or update that marker when the state changes.

## Portability Notes

- Keep the core workflow in markdown and repository files rather than product-specific metadata.
- Avoid hardcoding local absolute paths inside the roadmap.
- Treat model or owner labels as hints, not strict runtime requirements.
- To move this skill to another machine, copy the entire `workflow/` folder into `~/.codex/skills/` on the target machine and restart Codex.

## Learning Materials

- For practical day-to-day usage, read [workflow-user-guide.md](workflow-user-guide.md).
- For a teaching-oriented overview of recent model shifts, read [ai-model-evolution-2024-2026.md](ai-model-evolution-2024-2026.md).
- For a follow-along explanation of this local skill family, read [workflow-learning-pack.md](workflow-learning-pack.md).
- For a direct mapping from the completed Claude skills to the Codex-native versions, read [claude-to-codex-skill-guide.md](claude-to-codex-skill-guide.md).
- For a slide deck version of that mapping, open [deck-codex.html](deck-codex.html).
