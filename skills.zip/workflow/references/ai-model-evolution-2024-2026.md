# AI Model Evolution (2024-05 to 2026-02)

이 문서는 2026년 3월 19일 기준으로, 최근 2년 동안 AI 모델이 어떻게 바뀌었는지 빠르게 따라가기 위한 교육용 요약이다.

범위는 "대표 발표" 중심이다. 모든 모델을 나열하기보다, 실제 제품 설계와 에이전트형 워크플로우에 영향을 준 변화를 중심으로 정리한다.

## 먼저 봐야 할 5가지 변화

1. 멀티모달이 기본 전제가 됐다.
   - 텍스트 전용 챗봇에서 벗어나 음성, 이미지, 파일, 코드 작업이 한 모델 안에서 결합되기 시작했다.
2. "그냥 잘 답하는 모델"과 "생각하는 모델"이 분리됐다가 다시 합쳐지고 있다.
   - OpenAI의 `o` 계열, Anthropic의 hybrid reasoning, Google의 thinking 모델이 이 흐름을 밀었다.
3. 코드 생성보다 "긴 작업을 계속 밀고 가는 에이전트"가 중요해졌다.
   - 도구 호출, 파일 수정, 검증, 재시도, 장기 컨텍스트 유지가 핵심 경쟁력이 됐다.
4. 긴 컨텍스트와 안정적인 instruction following이 실전 차이를 만들기 시작했다.
   - 대형 코드베이스, 문서 묶음, 다단계 계획에서 체감 차이가 커졌다.
5. 오픈 계열 모델이 폐쇄형 최상위 모델과의 격차를 빠르게 줄였다.
   - DeepSeek 계열은 비용과 공개성 측면에서 시장 압력을 크게 만들었다.

## 대표 연표

| 날짜 | 모델/제품 | 왜 중요했는가 |
| --- | --- | --- |
| 2024-05-13 | GPT-4o | 실시간 멀티모달 상호작용을 전면에 내세우며 "omni" 방향을 분명히 했다. |
| 2024-06-21 | Claude 3.5 Sonnet | 코딩, 시각 이해, 가격 대비 성능에서 강한 균형점을 만들며 실무 기본값 후보가 됐다. |
| 2024-09-12 | OpenAI o1-preview | reasoning 전용 계열이 본격적으로 분리되며 "생각한 뒤 답하는 모델" 흐름이 명확해졌다. |
| 2024-12-11 | Gemini 2.0 | agentic era를 전면에 내세우며 native tool use와 멀티모달 출력 방향을 강화했다. |
| 2024-12-26 | DeepSeek-V3 | 고성능 MoE 오픈 모델이 비용 효율과 공개성 양쪽에서 강한 압박을 만들었다. |
| 2025-01-20 | DeepSeek-R1 | RL 기반 reasoning 오픈 모델이 폐쇄형 reasoning 라인업과 정면 경쟁하기 시작했다. |
| 2025-01-31 | OpenAI o3-mini | reasoning을 더 저렴하고 빠르게 사용할 수 있게 하며 실전 접근성을 높였다. |
| 2025-02-24 | Claude Sonnet 3.7 | hybrid reasoning을 전면화하면서 일반 응답과 extended thinking을 한 계열 안에 묶었다. |
| 2025-02-27 | GPT-4.5 | reasoning이 아닌, 더 큰 general-purpose GPT 축도 여전히 진화하고 있음을 보여줬다. |
| 2025-03-25 | Gemini 2.5 Pro | thinking model과 강한 코딩/추론 성능을 결합해 Google 계열의 존재감을 키웠다. |
| 2025-04-14 | GPT-4.1 | 코딩, instruction following, 1M context를 앞세운 API 중심 모델군으로 정리됐다. |
| 2025-04-16 | OpenAI o3 / o4-mini | reasoning 모델이 웹, 파일, Python 같은 도구를 agentically 결합하는 방향을 분명히 했다. |
| 2025-05-16 | Codex (codex-1) | 모델 그 자체보다 "비동기 병렬 코딩 에이전트" 제품 흐름이 현실화됐다는 점이 중요하다. |
| 2025-05-22 | Claude Sonnet 4 | Sonnet 라인이 실전 코딩과 에이전트 작업의 중심축으로 더 강화됐다. |
| 2025-08-07 | GPT-5 | GPT 계열과 reasoning/agent 성능이 다시 더 통합되는 방향을 보여줬다. |
| 2025-09-29 | Claude Sonnet 4.5 | 에이전트, 코딩, 장기 작업에서 Sonnet 계열의 실전성을 더 밀어 올렸다. |
| 2025-12-01 | DeepSeek-V3.2 | thinking in tool-use를 내세우며 오픈 계열도 agent training 쪽으로 빠르게 이동했다. |
| 2026-02-17 | Claude Sonnet 4.6 | 1M context와 장기 에이전트 성능을 전면에 내세우며 early 2026 기준 실무형 모델 경쟁을 이어갔다. |

## 흐름을 축으로 읽기

### 1. 멀티모달

- GPT-4o는 텍스트, 음성, 이미지, 비디오까지 한 모델 안에서 다루는 방향을 상징적으로 보여줬다.
- Gemini 2.0은 멀티모달뿐 아니라 "도구를 쓰는 모델"이라는 메시지를 함께 밀었다.
- 결과적으로 모델 선택 기준이 "문장 품질"만이 아니라 "파일/음성/이미지/브라우저를 함께 다룰 수 있나"로 이동했다.

### 2. Reasoning

- OpenAI는 `o1 -> o3 -> o4-mini`로 reasoning 계열을 구체화했다.
- Anthropic은 Sonnet 3.7부터 hybrid reasoning을 강조했다.
- Google은 Gemini 2.5를 "thinking model"로 설명했다.
- 이 변화는 프롬프트 설계도 바꿨다.
  - 짧게 한 번에 답을 요구하는 프롬프트보다
  - 단계, 검증, 도구 사용, 실패 시 복구까지 포함한 프롬프트가 중요해졌다.

### 3. Coding to Agents

- 2024년 중반까지는 "코드 잘 짜는가"가 중심 질문이었다.
- 2025년부터는 "긴 작업을 계속 유지하며, 파일을 바꾸고, 테스트를 돌리고, 다음 단계를 스스로 연결하는가"가 더 중요해졌다.
- OpenAI Codex, Claude Code 관련 발표, DeepSeek의 tool-use 방향은 모두 이 변화를 보여준다.

### 4. Context and Memory

- 긴 컨텍스트는 이제 마케팅 숫자보다 "실제로 긴 코드를 안정적으로 읽고 수정할 수 있는가"의 문제로 바뀌었다.
- GPT-4.1의 1M context, Gemini 2.5 계열의 1M context, Claude Sonnet 4.6의 1M context는 모두 장기 작업을 겨냥한다.

### 5. Open vs Closed

- DeepSeek-V3와 R1은 "오픈이어도 추론과 코딩이 충분히 경쟁력 있을 수 있다"는 인식을 넓혔다.
- 이 변화 때문에 폐쇄형 모델도 단순 품질뿐 아니라 에이전트 UX, 검증성, 도구 생태계까지 함께 경쟁하게 됐다.

## 2026년 3월 기준으로 보면

최근 2년의 핵심 변화는 "모델 성능 경쟁" 하나가 아니다. 실제로는 아래 3개가 동시에 일어났다.

1. 모델이 멀티모달 + reasoning + tool use를 함께 가지기 시작했다.
2. 단발 응답보다 장기 작업을 수행하는 에이전트 형태가 중요해졌다.
3. 워크플로우 설계가 모델 선택만큼 중요해졌다.

즉, 이제 좋은 결과는 "좋은 모델" 하나로 나오지 않는다. `모델 + 도구 + 상태 관리 + 검증 루프`의 조합으로 나온다.

## 이 문서를 workflow 스킬과 연결해서 읽는 법

현재 구현한 `workflow` 스킬은 바로 이 변화에 맞춘 로컬 운영 규약이다.

- reasoning 모델 시대:
  `ROADMAP.md`로 단계를 외부화해 긴 작업을 유지한다.
- agent 시대:
  `run -> complete -> sync` 루프로 상태를 복구하고 이어간다.
- tool-use 시대:
  helper script로 상태 판별과 기계적 갱신을 분리한다.
- product fragmentation 시대:
  Claude의 의도는 유지하되 Codex가 실제 제공하는 도구에 맞게 변환한다.

## 수업용 질문

1. GPT-4o와 o1의 차이는 "더 똑똑하다"가 아니라 어떤 작업 방식의 차이인가?
2. Claude Sonnet 3.7과 Google Gemini 2.5가 공통으로 밀고 있는 개념은 무엇인가?
3. DeepSeek-R1이 시장에 준 충격은 단순 성능 때문인가, 아니면 배포 방식 때문인가?
4. 왜 2025년부터는 `prompt engineering`보다 `workflow engineering`이 더 중요해졌는가?
5. 왜 `ROADMAP.md` 같은 외부 상태 파일이 agent workflow에서 중요해지는가?

## 공식 자료

- OpenAI, "Hello GPT-4o" (2024-05-13)
  - https://openai.com/index/hello-gpt-4o
- Anthropic, "Introducing Claude 3.5 Sonnet" (2024-06-21)
  - https://www.anthropic.com/news/claude-3-5-sonnet
- OpenAI, "Introducing OpenAI o1-preview" (2024-09-12)
  - https://openai.com/index/introducing-openai-o1-preview/
- Google, "Introducing Gemini 2.0: our new AI model for the agentic era" (2024-12-11)
  - https://blog.google/innovation-and-ai/models-and-research/google-deepmind/google-gemini-ai-update-december-2024/
- DeepSeek, "Introducing DeepSeek-V3" (2024-12-26)
  - https://api-docs.deepseek.com/news/news1226
- DeepSeek, "DeepSeek-R1 Release" (2025-01-20)
  - https://api-docs.deepseek.com/news/news250120
- OpenAI, "OpenAI o3-mini" (2025-01-31)
  - https://openai.com/index/openai-o3-mini/
- Anthropic, "Claude Sonnet" announcements page, including Sonnet 3.7 (2025-02-24), Sonnet 4 (2025-05-22), Sonnet 4.5 (2025-09-29), Sonnet 4.6 (2026-02-17)
  - https://www.anthropic.com/claude/sonnet
- OpenAI, "Introducing GPT-4.5" (2025-02-27)
  - https://openai.com/index/introducing-gpt-4-5/
- Google, "Gemini 2.5: Our most intelligent AI model" (2025-03-25)
  - https://blog.google/technology/google-deepmind/gemini-model-thinking-updates-march-2025
- OpenAI, "Introducing GPT-4.1 in the API" (2025-04-14)
  - https://openai.com/index/gpt-4-1/
- OpenAI, "Introducing OpenAI o3 and o4-mini" (2025-04-16)
  - https://openai.com/index/introducing-o3-and-o4-mini/
- OpenAI, "Introducing Codex" (2025-05-16)
  - https://openai.com/index/introducing-codex/
- OpenAI, "Introducing GPT-5 for developers" (2025-08-07)
  - https://openai.com/index/introducing-gpt-5-for-developers/
- DeepSeek, "DeepSeek-V3.2 Release" (2025-12-01)
  - https://api-docs.deepseek.com/news/news251201
