# Debug Checklists

Load only the section that matches the chosen debug perspective.

## Reproduction And Logs

- What is the strongest known failing command, test, or user path?
- Is the failure deterministic, time-based, environment-based, or intermittent?
- What logs, traces, or stack frames narrow the scope?
- What evidence directly contradicts the current leading hypothesis?

## Code-Path And Data-Flow

- Which entrypoints, handlers, or background jobs are on the failing path?
- What state, payload, or identifier flows through the bug path?
- Where can the observed bad state first appear?
- Which guard, branch, or transformation would most likely explain the symptom?

## Config And Integration

- Could configuration, environment flags, secrets, network boundaries, or third-party contracts explain the failure?
- Are there recent manifest, schema, or deployment-related changes?
- Does the failure depend on environment-specific behavior such as time zone, cache, or credentials?
- Which integration boundary is most likely to be returning surprising data?

## Concurrency And Performance

- Could timing, retries, batching, async boundaries, or race conditions explain the symptom?
- Is there evidence of stale reads, duplicate writes, lock contention, or background task overlap?
- Do timeouts, resource pressure, or queue ordering affect reproduction?
- What focused experiment would best confirm or rule out concurrency as the primary cause?
