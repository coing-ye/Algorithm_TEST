---
name: team-debug
description: Run a multi-perspective root-cause debugging workflow in Codex. Use when the user explicitly invokes `$team-debug`, asks for parallel or hypothesis-driven debugging, or needs an ambiguous, intermittent, or cross-module bug investigated and optionally fixed.
---

# Team Debug

Run a command-style debugging workflow in Codex. This skill is for bugs where a normal single-threaded pass is likely to miss the real root cause.

## Quick Start

Use this skill when the user explicitly asks for a team-style debug, for example:

- `$team-debug 로그인 후 10분쯤 지나면 세션이 끊기는 원인을 찾아줘`
- `$team-debug tests/payments.test.ts`
- `$team-debug "간헐적인 중복 청구 문제를 재현하고 고쳐줘"`

## Debug Flow

1. Resolve the debug target.
   - Failing test, log snippet, stack trace, repro command, or path -> inspect it directly.
   - Vague bug description -> resolve the likely files, commands, and entrypoints first.
   - No explicit target -> inspect the nearest failing test command, recent bug-fix commits, `ROADMAP.md` failure notes, or obvious error logs before asking the user for more detail.
2. Reproduce or collect evidence.
   - Prefer a failing command, test, stack trace, or deterministic repro.
   - If the bug is not directly reproducible, gather the strongest nearby evidence before spawning agents.
   - If this debug request follows earlier failed attempts, collect the prior failure notes, recently changed files, and the closest reproducible failure before starting fresh analysis.
3. Size the scope.
   - Tiny: one narrow failure path and one or two files
   - Small: one subsystem with a few related files
   - Medium: multiple modules or mixed signals from code and logs
   - Large: cross-cutting, intermittent, or concurrency-heavy behavior
4. Launch parallel hypothesis agents.
   - This skill is an explicit request for delegated investigation, so `spawn_agent` is allowed.
   - Prefer `explorer` agents for analysis.
   - Choose from: reproduction/logs, code-path/data-flow, config/integration, concurrency/performance.
   - Keep the analysis phase read-only. Fixes happen only after the evidence has converged.
5. Synthesize root-cause hypotheses.
   - Rank by evidence, not by creativity.
   - Call out the strongest confirming and disconfirming evidence for each serious hypothesis.
6. Decide whether to fix.
   - If the user asked only for diagnosis, stop after the evidence and root-cause ranking.
   - If the user asked for a fix and the evidence is strong enough, implement locally or with bounded workers only when write scopes are genuinely disjoint.
7. Verify.
   - Re-run the failing command, targeted test, or closest repro.
   - If the bug was intermittent, record the residual uncertainty instead of claiming certainty.

## Codex-Native Adaptation

- Multi-angle debugging uses `spawn_agent`, not hidden team primitives.
- Questions stay short and plain-text when a missing repro detail blocks progress.
- Root cause outranks patching symptoms.
- Fix execution is optional and should follow only after the investigation has produced a credible leading hypothesis.
- If the bug was escalated from earlier failed attempts, treat those attempts as negative evidence and avoid repeating them blindly.

## Evidence Collection Heuristics

- If no explicit repro is given, check the most relevant local failure signal first:
  - targeted failing test or test suite
  - recent bug-fix commits that touch the same area
  - `ROADMAP.md` notes such as `❌ 실패` or retry-style commentary
  - nearby logs, stack traces, or obvious runtime commands
- If previous attempts already changed files in this area, inspect those changes before forming new hypotheses.
- Prefer one strong failing signal over many weak clues when deciding what to hand to agents.

## Analysis Perspectives

Read [references/debug-checklists.md](references/debug-checklists.md) and load only the sections that match the chosen perspectives.

Recommended perspective sets:

- Tiny: reproduction/logs, code-path/data-flow
- Small: reproduction/logs, code-path/data-flow
- Medium: reproduction/logs, code-path/data-flow, config/integration
- Large: reproduction/logs, code-path/data-flow, config/integration, concurrency/performance

## Scale, Model, And Lead Rules

- Tiny and Small debugging tasks usually need 2 analysis agents.
- Medium debugging tasks usually need 3 analysis agents.
- Large, intermittent, or concurrency-heavy debugging tasks usually need 4 analysis agents.
- Prefer smaller analysis agents for straightforward repro or path tracing, and prefer a stronger analyst for concurrency, state-machine, or architecture-heavy failures.
- Lead owns evidence quality, hypothesis ranking, repro selection, and final validation. Do not let the lead drift into duplicate free-form analysis.
- If the top hypothesis affects auth, payments, migrations, data integrity, or concurrency, cross-check the top one or two hypotheses before presenting a confident root cause.

## Agent Prompt Template

Use prompts shaped like this:

```text
You are the {reproduction/logs | code-path/data-flow | config/integration | concurrency/performance} debug analyst.

Target:
- {failing command, stack trace, path list, or resolved file list}

Observed symptoms:
- {lead summary}

Checklist:
- Load only the matching section from references/debug-checklists.md

Output requirements:
- Report only evidence-backed hypotheses.
- Include concrete files, commands, traces, or line references when possible.
- Rank findings as: Leading hypothesis, Plausible alternatives, Rejected hypotheses.
- Call out what should be tested next to confirm or falsify the leading hypothesis.
```

## Fix Execution Rules

- Do not implement a fix until the investigation has a credible leading hypothesis.
- If the fix is narrow, prefer local implementation in the main Codex session.
- Use `worker` agents only for disjoint write scopes and only when the user explicitly wants delegated execution or the fix naturally separates into non-overlapping files.
- If the fix touches shared contracts, migrations, or concurrency-sensitive code, prefer sequential execution and explicit validation.
- Finish or close the analysis agents before worker edits begin so the fix stage has one clear source of truth.

## ROADMAP Integration

- If `ROADMAP.md` exists, record the debugging work under the active workflow only when the investigation is clearly part of that workflow.
- If the user wants the debug findings tracked, add a workflow-compatible section such as `## 디버깅 조사 (YYYY-MM-DD)` or append the result to the current task's `변경:` note.
- When a root cause is confirmed but the fix is postponed, prefer adding a concrete unchecked task rather than leaving only prose.

## Output

Always separate:

1. Evidence
2. Root-cause ranking
3. Fix or next-step recommendation
4. Verification result or remaining uncertainty
