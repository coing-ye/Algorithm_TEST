---
name: workflow-plan
description: Create or refresh a Codex-native `ROADMAP.md` execution plan from a feature request, bug, refactor, migration, or research task. Use when the user asks to start a workflow, plan tasks, break work into steps, initialize roadmap state, or explicitly invokes `$workflow-plan`.
---

# Workflow Plan

Build or refresh the roadmap before substantial work. This skill is the Codex-native replacement for the planning phases of the Claude workflow.

This is primarily an internal phase skill behind `$workflow`. Prefer `$workflow` for normal usage unless the user explicitly wants to create or refresh the roadmap without running the full router.

## Planning Flow

1. Detect the workspace root.
   - Prefer the git root.
   - Fall back to the current working directory.
2. Inspect the current project before writing.
   - Read manifests, lockfiles, README, existing `ROADMAP.md`, tests, and the files closest to the request.
   - Check `git status --short` so pending user edits are not overwritten.
   - Prefer the smallest roadmap that will survive session breaks. Avoid speculative or ceremonial tasks.
3. Decide whether this should stay in normal planning or be escalated to an adjacent team skill.
   - If the request is explicitly a large refactor, asks for multiple refactor options, or appears to span many files or architectural boundaries, recommend `$team-refactor` as the multi-perspective analysis path.
   - If the request is mainly debugging and the failure looks intermittent, stateful, cross-module, or difficult to reproduce from one code slice, recommend `$team-debug` as the multi-hypothesis investigation path.
   - If the user explicitly wants to stay in `$workflow-plan`, keep planning locally and record the refactor tasks directly in `ROADMAP.md`.
4. Decide whether bootstrap clarification is needed before task splitting.
   - If `ROADMAP.md` does not exist, the request is for a new project, and nearby manifests do not reveal the stack, ask one concise environment question first.
   - Prefer a short direct question such as `어떤 환경으로 시작할까요? Node.js CLI, React 웹앱, Python 스크립트 중 하나로 정하면 ROADMAP을 만들겠습니다.`
   - Do not ask this question when the request or repository already makes the environment obvious.
5. Decide whether design clarification is needed before task splitting.
   - If the request is a new feature and a missing decision could change a public interface, schema, migration, billing behavior, or external contract, ask one concise question first.
   - When all of these are true, strongly prefer a short design check before task splitting: no existing `ROADMAP.md`, no nearby design note such as `docs/design/*.md`, and the request is a genuinely new feature rather than a bug fix or refactor.
   - When useful, record stable design choices in an optional `## 설계 결정` section above the active tasks.
6. Decide whether to create or refresh.
   - If `ROADMAP.md` exists, preserve valid completed items and `변경:` notes.
   - If no roadmap exists, create one for multi-step work.
7. Write or refresh `ROADMAP.md`.
   - Use one active section named `## 현재 작업 (YYYY-MM-DD)`.
   - Put `모드:` immediately below the section header.
   - Default to `모드: 개별선택` unless the user explicitly asks for automatic continuation.
   - Keep checklist items in the form `- [ ] N. 작업명 (codex)`.
   - Preserve older owner labels such as `(impl-sonnet)` when refreshing an existing roadmap.
   - End the checklist block with `진행률: X/Y (Z%)`.
8. Add `## Task Briefs` for concrete execution guidance.
   - Include `참조`, `대상 파일`, `요구사항`, `인터페이스`, `제약사항`, and `완료조건`.
   - When the execution shape is unusual, add `실행전략:` with one of `local-direct`, `parallel-ok`, `refactor-branch`, `root-cause-debug`, or `team-debug-branch`.
   - For bug work, include reproduction clues, failing commands, or observed symptoms in the task brief so later execution does not have to rediscover the problem statement.
   - When a debugging task is likely to need escalation later, add a durable hint such as `복잡도태그: [complex-bug]`.
9. Sync the session plan with `update_plan`.
   - Keep one active step at a time.
   - Match the plan ordering to the roadmap numbering.

## Quality Bar

- Usually produce 3-5 tasks.
- Order tasks by dependency, not by narrative.
- Use task numbering as execution priority.
- Split tests into a separate task unless they are trivial and inseparable.
- Record assumptions explicitly.
- Skip roadmap creation for truly trivial one-step work and do the task directly instead.
- When the request is a substantial refactor and the user wants multi-angle analysis, prefer recommending `$team-refactor` over inventing a fake single-threaded certainty.
- When the request is a substantial debugging problem and the bug is ambiguous across multiple subsystems, prefer recommending `$team-debug` over pretending the next step is obvious.
- When bootstrapping a new project with no detectable stack, ask one short environment question before writing the first roadmap.
- Ask one concise blocking question only if a missing decision changes a public API, schema, migration, billing behavior, or external contract.
- Do not leave the answer as prose only; update files on disk when roadmap planning is appropriate.
- When refreshing an older roadmap, preserve useful labels like `(impl-sonnet)` as hints rather than normalizing them away.
- Do not add placeholder tasks for review, commit, push, or external coordination unless the user explicitly asked for them.
- Use `실행전략:` hints only when they materially change how `$workflow-run` should behave. Most tasks do not need one.
- If repeated execution tuning will matter across sessions, add a compact `## 전략 설정` section instead of burying those hints inside one task brief.
- If a new feature starts without design docs and would create a public-facing contract, prefer one concise design question over a large speculative roadmap.

## Output

End with a short summary of:
- analyzed root
- files created or updated
- key assumptions
- the next recommended skill invocation, usually `$workflow-run` or `$workflow-complete` if only closeout remains
