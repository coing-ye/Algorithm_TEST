---
name: workflow-run
description: Execute the next unblocked task from `ROADMAP.md` in Codex and keep `ROADMAP.md`, `update_plan`, and user-visible progress aligned. Use when the user asks to continue, resume, execute the next step, auto-advance through a workflow, or explicitly invokes `$workflow-run`.
---

# Workflow Run

Run the next task directly in Codex. This skill is tuned for Codex's real capabilities: commentary updates, `update_plan`, local shell/tool use, `apply_patch`, and optional subagents only when the user explicitly wants them.

This is primarily an internal phase skill behind `$workflow`. Prefer `$workflow` for normal usage unless the user explicitly wants to force the execution phase.

## Execution Flow

1. Detect the workspace root and read `ROADMAP.md`.
   - Prefer `../workflow/scripts/roadmap_state.py <root> --json` first so task recovery is consistent.
   - When you need to set or refresh the active marker consistently, prefer `../workflow/scripts/roadmap_update.py <root> start --task N`.
2. Recover the current task.
   - Prefer an explicit `🔄 진행 중` marker.
   - Otherwise choose the lowest-numbered unblocked unchecked item.
   - If no roadmap exists but the request clearly requires multi-step work, bootstrap a minimal roadmap first.
3. Sync `update_plan`.
   - Set the active task to `in_progress`.
   - Keep blocked or future tasks as `pending`.
4. Execute the task.
   - Inspect the relevant files before editing.
   - Add or refresh a `🔄 진행 중` marker when the roadmap style uses explicit active markers.
   - Provide commentary updates before substantial work and before file edits.
   - Use `apply_patch` for manual edits.
   - Run the relevant verification commands.
5. Close out the task.
   - If the task is complete, hand off to `$workflow-complete` semantics. Prefer `../workflow/scripts/roadmap_update.py <root> complete --task N --date YYYY-MM-DD --change "..."` for consistent closeout.
   - If the task is blocked, prefer `../workflow/scripts/roadmap_update.py <root> block --task N --reason "..."` so `모드: 중단 (...)` and `❌ 실패` stay in sync.
   - If the task is partially complete, record the state in `ROADMAP.md` and keep the plan aligned.

## Strategy Matrix

Choose the simplest real strategy that fits the task:

- `local-direct`
  - Default for ordinary implementation, tests, documentation, and small fixes.
  - Stay in the main Codex session and finish the current runnable task end to end.
- `parallel-ok`
  - Use only when the user explicitly asked for delegation or parallel agent work, and the task can be split into disjoint write scopes.
  - Prefer bounded worker ownership instead of overlapping edits.
- `refactor-branch`
  - If the current task is really a broad refactor analysis or coordinated refactor execution problem, stop treating it like a normal run step and recommend `$team-refactor`.
- `root-cause-debug`
  - For unclear bug work, stay sequential and root-cause-first.
  - If repeated attempts keep uncovering new subsystems or the failure mode remains ambiguous, pause and re-plan instead of faking certainty.
- `team-debug-branch`
  - If the task is fundamentally a multi-hypothesis debugging problem, especially intermittent, cross-module, stateful, or concurrency-heavy, recommend `$team-debug` instead of forcing a single-threaded implementation path.

If `## Task Briefs` includes an `실행전략:` hint, treat it as a durable hint from planning rather than a rigid command.
If `## Task Briefs` includes `복잡도태그: [complex-bug]`, treat that as a durable early-warning hint toward `$team-debug`.

## Codex-Native Rules

- In Default mode, do the implementation directly unless the user explicitly asks for subagents, delegation, or parallel agent work.
- If the user did not ask for delegation, do not turn a single runnable task into a subagent workflow.
- If the user explicitly wants delegation, use `spawn_agent` only for bounded non-overlapping work and keep the write scopes disjoint.
- If the current task is really a large refactor analysis or coordinated refactor execution request, prefer handing that branch to `$team-refactor` instead of improvising an ad-hoc agent mesh inside `$workflow-run`.
- If the current task is really an ambiguous root-cause debugging request, prefer handing that branch to `$team-debug` instead of improvising a fragile ad-hoc investigation inside `$workflow-run`.
- Keep progress visible with short commentary updates while working.
- Do not invent completion. Base roadmap updates on actual file changes and actual verification.
- Fix root causes rather than workarounds when debugging.
- After repeated failed attempts, roadmap notes that imply retry history, cross-module symptom spread, or evidence that the repro depends on competing hypotheses, stop and recommend `$team-debug` rather than serial guesswork.
- If a blocking ambiguity affects a public contract, ask one concise question instead of guessing.
- Prefer `roadmap_update.py start --task N` over manual marker edits because it rejects completed, cancelled, failed, or dependency-blocked tasks.
- Express retries, blockers, and cancellations in roadmap notes or commentary rather than pretending there is extra workflow metadata behind the scenes.
- Keep `workflow-run` scoped to implementation, local verification, and roadmap state. Review, commit, push, and PR steps are explicit follow-ups.
- If verification needs dependency installs, network access, or unsandboxed commands, request escalation instead of silently skipping checks.

## Auto Mode

- If `모드: 자동진행` is set, continue to the next unblocked task after closing the current one, stopping only for blockers, failures, or user intervention.
- If `모드: 개별선택` or `모드: 대기 중`, stop after the current task unless the user explicitly asks to keep going.

## Output

End with a short summary of:
- task executed
- files changed
- verification run
- whether escalation to `$team-debug` or `$team-refactor` is warranted
- whether the next task is ready
