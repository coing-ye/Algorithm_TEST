---
name: workflow-sync
description: Reconcile `ROADMAP.md` and the in-session plan with the work that has already happened in Codex. Use when task status changed after edits, review, tests, manual work, or blockers, or when the user explicitly invokes `$workflow-sync` to update roadmap state.
---

# Workflow Sync

Use this after work has already happened and the roadmap needs to catch up.

This is primarily an internal phase skill behind `$workflow`. Prefer `$workflow` for normal usage unless the user explicitly wants reconciliation after out-of-band edits, tests, or review.

## Sync Flow

1. Detect the workspace root.
   - Prefer the git root.
   - Fall back to the current working directory.
2. Prefer `../workflow/scripts/roadmap_state.py <root> --json` to summarize the current roadmap state.
3. Read `ROADMAP.md`, the most relevant changed files, and `git status --short` when inside a repository.
4. Determine the true state of the current task.
   - `completed`: implementation and required validation are done
   - `in_progress`: work started but is not finished
   - `blocked`: progress stopped because of a concrete blocker
   - `cancelled`: task should not continue
5. Update the roadmap to match reality.
   - Prefer `../workflow/scripts/roadmap_update.py` for mechanical roadmap edits when the target state is clearly known.
   - `completed`: mark `- [x]`, add date if useful, add a `변경:` line, recalculate `진행률:`
   - `in_progress`: add or refresh `🔄 진행 중`
   - `blocked`: record the blocker near the task or in `모드: 중단 (...)`
   - `cancelled`: prefer `../workflow/scripts/roadmap_update.py <root> cancel --task N --reason "..."` when the stop is intentional. This is task-scoped by default and should not stop unrelated runnable tasks.
6. Sync `update_plan` using Codex-supported statuses only.
   - `completed` -> `completed`
   - `in_progress` -> `in_progress`
   - `blocked` and `cancelled` -> keep the step `pending` and record the actual state in `ROADMAP.md`
7. Summarize what was reconciled and what should happen next.

## Rules

- Never mark a task done without evidence in files, tests, or other verifiable outputs.
- Preserve valid history and prior `변경:` notes.
- If the roadmap is missing but the work clearly became multi-step, create a minimal roadmap instead of leaving the state implicit.
- If progress reveals a new task or blocker, add it explicitly rather than hiding it in prose.
- Do not assume `update_plan` can represent every roadmap state; `blocked` and `cancelled` must live in the roadmap text.
- Do not reopen completed or cancelled tasks unless the user explicitly asks to resume or recreate them.
- Keep sync updates concise and factual.
