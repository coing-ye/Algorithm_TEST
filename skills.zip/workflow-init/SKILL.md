---
name: workflow-init
description: Inspect the project state, recover workflow progress from `ROADMAP.md`, or bootstrap a new Codex workflow when the user starts or resumes work without a clear active phase.
---

# Workflow Init

Use this skill when the user starts `$workflow` without a concrete phase and the current state must be discovered first.

This is primarily an internal phase skill behind `$workflow`. Prefer `$workflow` for normal usage unless the user explicitly wants the initialization or recovery phase.

## Init Flow

1. Detect the workspace root.
   - Prefer the git root.
   - Fall back to the current working directory.
2. Inspect the current state before planning or coding.
   - Prefer `../workflow/scripts/roadmap_state.py <root> --json` when `ROADMAP.md` exists, then read the file directly only as needed.
   - Read `ROADMAP.md` if it exists.
   - Check `git status --short` when inside a repository.
   - Check recent commits with `git log --oneline -5` when inside a repository and recent work context matters.
   - Search for nearby `TODO` or `FIXME` markers when no roadmap exists and the active work is unclear.
   - Inspect the closest manifests, README, entrypoints, and tests when they help explain the active work.
   - Use nearby manifests such as `package.json`, `pyproject.toml`, `Cargo.toml`, `go.mod`, or `Gemfile` to infer the environment before asking the user.
   - If the user references a PR, review, or branch, inspect the local git state that actually exists here or ask for the missing context. Do not assume hidden PR metadata.
3. Recover durable workflow state from `ROADMAP.md`.
   - Search for `🔄 진행 중`, unchecked checklist items, `모드:`, and `진행률:`.
   - Prefer the first active section with unfinished work.
   - If the roadmap is unreadable or obviously corrupted and the repo is in git, try `git show HEAD:ROADMAP.md` and then recent ROADMAP history before giving up.
   - Preserve an existing `## 전략 설정` section when present and treat it as a durable execution hint, not as disposable prose.
   - If a roadmap exists with unfinished work, sync `update_plan` to the active tasks.
4. Decide the next phase.
   - Unfinished roadmap with an executable task -> hand off to `$workflow-run`
   - Unfinished roadmap but ambiguous selection in `모드: 개별선택` or `모드: 대기 중` -> recommend the next task and ask one short question
   - No roadmap, a clear request, and no detectable stack for a greenfield project -> ask one short environment question first, then hand off to `$workflow-plan`
   - A debugging request with an intermittent or cross-module failure mode -> recommend `$team-debug`
   - No roadmap but a clear user request -> hand off to `$workflow-plan`
   - No roadmap and no clear request -> summarize the current repo status and suggest the next likely workflow action from git state, nearby TODO/FIXME markers, and obvious failing paths

## Bootstrap Question Rules

- Ask an environment question only when all of these are true:
  - `ROADMAP.md` does not exist
  - nearby manifests or entrypoints do not already reveal the stack
  - the request is greenfield, educational, prototype-like, or otherwise asks Codex to create a new project
  - the stack choice will change file layout, tooling, or commands
- Keep the question to one short sentence in plain text.
- Prefer naming 2-3 likely environments instead of asking an open-ended architecture question.
- Example:
  `새 프로젝트라면 어떤 환경으로 시작할까요? Node.js CLI, React 웹앱, Python 스크립트 중 하나로 정하면 그 기준으로 ROADMAP을 만들겠습니다.`
- If the user already implied the environment in natural language, do not ask again.
- If the repository has no clear project files yet, treat the answer as a bootstrap choice and then continue directly into `$workflow-plan` instead of inventing a separate hidden setup phase.

## Suggested Next Actions Heuristics

- When `$workflow` is invoked without a roadmap and without a concrete request, prefer concrete suggestions over generic prose.
- Use recent git state as the first signal:
  - uncommitted changes -> suggest reviewing, testing, or closing out those changes
  - recent `feat`-style commits -> suggest tests, docs, or follow-up implementation
  - recent `fix`-style commits -> suggest regression checks
- Use nearby `TODO` or `FIXME` markers as the second signal when they appear close to active entrypoints or recently changed files.
- If the repo looks greenfield and mostly empty, suggest starting with `$workflow` plus a concrete app request rather than pretending active work already exists.

## Recovery Rules

- Treat `ROADMAP.md` as the durable source of truth across sessions.
- Prefer explicit `🔄 진행 중` markers over inferred unchecked items.
- If a roadmap contains only completed work, do not silently reopen tasks.
- If the roadmap format is partially invalid, recover from the valid checklist items instead of discarding the file.
- If the roadmap cannot be parsed and the repository has git history, try the most recent committed ROADMAP before falling back to manual recovery.
- When `모드: 중단 (...)` is present, surface the blocker plainly and ask whether to resume from that point.
- When `모드: 취소 (...)` is present, surface the cancellation reason plainly and do not reopen the task unless the user explicitly asks.
- Preserve and surface `## 전략 설정` hints when they exist because they may explain prior execution choices or escalation thresholds.
- Do not depend on `.claude/` conventions or hidden product metadata. Use repo files and instructions that are actually available in Codex.

## Output

End with a short summary of:
- detected root
- roadmap status
- whether an environment question was needed
- suggested next actions when there is no active roadmap
- recommended next phase, usually `$workflow-run` or `$workflow-plan`
