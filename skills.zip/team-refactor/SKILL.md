---
name: team-refactor
description: Run a multi-perspective refactoring workflow in Codex. Use when the user explicitly invokes `$team-refactor`, asks for a structured refactor plan from multiple angles, or wants a parallel analysis followed by optional parallel implementation across disjoint file sets.
---

# Team Refactor

Run a command-style refactor workflow in Codex. This skill adapts the Claude `team-refactor` idea to Codex with analysis agents first, then optional worker agents for approved changes.

## Quick Start

Use this skill when the user explicitly asks for a team-style refactor, for example:

- `$team-refactor src/auth`
- `$team-refactor src/auth "split responsibilities"`
- `$team-refactor app/services`

## Refactor Flow

1. Resolve the target.
   - Path or directory -> inspect that area directly.
   - Goal description -> use local exploration to identify the relevant files first.
   - No argument -> inspect `git diff HEAD` and propose candidates from recent changes.
2. Size the scope.
   - Tiny: 2 files or fewer and about 50 lines or fewer
   - Small: up to 5 files or about 100 lines
   - Medium: up to 15 files or about 500 lines
   - Large: anything bigger
3. Run parallel analysis agents.
   - This skill is an explicit request for delegated work, so `spawn_agent` is allowed.
   - Prefer `explorer` agents for the analysis phase.
   - Choose from: structure, dependencies, test impact, architecture.
   - High-risk override: if the refactor touches public interfaces, migrations, or shared contracts, include architecture or dependency analysis even when the scope is otherwise small.
4. Synthesize concrete refactor proposals.
   - Each proposal should name the target files, purpose, expected impact, and dependency order.
   - Detect file overlap between proposals.
5. Ask for execution approval.
   - Codex has no Claude menu widget here, so ask one concise plain-text question.
   - Offer three paths: execute all, execute selected proposal numbers, or keep only the plan.
6. If approved, execute with worker agents or locally.
   - Use `worker` agents only for disjoint write scopes.
   - Keep overlapping proposals sequential.
7. Verify and close out.
   - Run the relevant tests or validation commands.
   - Update or create `ROADMAP.md` when the work is multi-step or the user wants tracking.

## Codex-Native Adaptation

- Claude Agent Team -> `spawn_agent`
- Claude `AskUserQuestion` -> one short direct question in plain text
- Claude worktree isolation -> worker agents with explicit disjoint file ownership
- Claude team shutdown rituals -> integrate results, then close agents when no longer needed
- Claude automatic roadmap writeback -> only when the refactor is substantial or the user wants tracking

## Target Resolution

- If the input is a path, confirm it exists and inspect nearby files.
- If the input is a goal description, use `rg`, manifests, tests, and entrypoints to resolve the code slice first.
- If the input is empty, use `git diff HEAD` plus `git status --short` to identify likely refactor candidates.
- If the target is still ambiguous after local exploration, ask one short clarifying question.

## Analysis Perspectives

Read [references/refactor-checklists.md](references/refactor-checklists.md) and load only the sections that match the chosen perspectives.

Recommended perspective sets:

- Tiny: structure, dependencies
- Small: structure, dependencies
- Medium: structure, dependencies, test impact
- Large: structure, dependencies, test impact, architecture

## Scale, Model, And Lead Rules

- Tiny and Small refactors usually need 2 analysis agents.
- Medium refactors usually need 3 analysis agents.
- Large or interface-heavy refactors usually need 4 analysis agents.
- Prefer smaller analysis agents for ordinary structure or dependency passes, and prefer a stronger architecture or dependency analyst when the work spans 3 or more modules, changes shared contracts, or earlier analysis looks weak.
- Lead should coordinate proposal synthesis, overlap detection, approval gating, and final validation. Do not turn the lead into another full-time analyst.
- Proposals that touch migrations, shared interfaces, public contracts, or broad dependency graphs should get a second analyst confirmation before execution approval.
- When proposals overlap on the same contract but not the same file, treat that as coupling and keep execution sequential unless the interaction is explicitly validated.

## Analysis Prompt Template

Use prompts shaped like this:

```text
You are the {structure/dependencies/test-impact/architecture} refactor analyst.

Target:
- {path list or resolved file list}

Goal:
- {user goal or lead summary}

Checklist:
- Load only the matching section from references/refactor-checklists.md

Output requirements:
- Report concrete problems with file:line when possible.
- Propose specific refactors, not generic advice.
- For each proposal, include target files, expected scope, and dependencies on other proposals.
- Call out proposal overlap with other files or modules when visible.
```

## Approval Question

After synthesis, ask one concise question such as:

`리팩토링 제안 4개를 정리했습니다. 전부 실행할까요, 번호를 골라 선택 실행할까요, 아니면 계획만 ROADMAP에 남길까요?`

Do not ask this question until the proposals are concrete.

## Worker Execution Rules

- Use `worker` agents only after the user approves execution.
- Every worker must own a disjoint write set.
- Tell each worker they are not alone in the codebase, they must not revert others' changes, and they must stay within their assigned files.
- If proposals overlap on the same file, execute them sequentially instead of in parallel.
- If proposals touch a shared interface, migration boundary, or contract change, prefer sequential execution even when the file sets are disjoint.
- Keep the lead focused on plan coordination, integration review, and shared validation.

Suggested worker prompt shape:

```text
You are implementing an approved refactor proposal.

Ownership:
- Only edit: {file list}

Goal:
- {approved proposal summary}

Constraints:
- You are not alone in the codebase.
- Do not revert edits made by others.
- Stay within the owned files unless the lead explicitly expands scope.
- Preserve behavior unless the proposal states otherwise.
- Report changed files and verification run.
```

## ROADMAP Integration

- If `ROADMAP.md` already exists, add a workflow-compatible section for the refactor when the work spans multiple steps.
- If no roadmap exists and the refactor is large enough that recovery matters, create a minimal roadmap compatible with `$workflow`.
- For plan-only mode, keep the tasks unchecked.
- For executed proposals, mark completed items and add `변경:` notes.

Example:

```md
## 리팩토링 계획 (2026-03-21)
> 출처: $team-refactor src/auth

- [ ] 1. [구조] 인증 서비스 책임 분리 (codex)
- [ ] 2. [의존성] 순환 의존성 해소 (codex) [blockedBy: 1]
- [ ] 3. [테스트] 회귀 테스트 보강 (codex) [blockedBy: 2]
진행률: 0/3 (0%)
```

## Output

Always separate:

1. Analysis
2. Approval state
3. Execution result

If the user chooses plan-only, stop after recording the plan and summarizing the next recommended step.
