# Team Refactor Checklists

Load only the section that matches the assigned analysis perspective.

## Structure

- File and module shape
  - oversized files or functions
  - mixed responsibilities in one module
  - poor directory grouping for domain boundaries
- Naming
  - unclear names for modules, functions, or state
  - inconsistent naming relative to nearby code
- Exports
  - leaking internal helpers
  - barrel files that hide ownership or make imports unclear

## Dependencies

- Import graph
  - inconsistent path strategy
  - unnecessary or duplicated imports
- Coupling
  - high fan-out modules
  - shotgun surgery across multiple files
  - feature envy or cross-layer reach-through
- Cycles
  - direct or indirect circular dependencies
  - proposal options to break the cycle
- Shared extraction
  - duplicated utilities
  - duplicated type definitions
  - repeated patterns that belong in a shared abstraction

## Test Impact

- Coverage gaps
  - no tests around the refactor target
  - missing error-path or edge-case coverage
- Regression risk
  - public API behavior that must stay stable
  - downstream modules or consumers likely to break
- Test strategy
  - whether tests should be added before refactoring
  - which unit or integration tests should move with the refactor
- Mocking problems
  - mocks that hide interface drift
  - heavy coupling between tests and internal structure

## Architecture

- Pattern consistency
  - mismatch with the existing project's layering or style
  - incompatible async or error-handling patterns
- Abstraction
  - leaky abstraction
  - over-abstraction without real need
  - wrong level of abstraction in one module
- DRY and maintainability
  - duplicated logic
  - false DRY risk where merging would reduce clarity
- Future change points
  - hardcoded strategy or config
  - unstable extension points
  - interfaces that should be narrower or inverted
