---
name: team-review
description: Run a multi-perspective parallel code review in Codex. Use when the user explicitly invokes `$team-review`, asks to review a PR, commit range, staged or working-tree diff, or wants findings from multiple angles such as correctness, security, performance, tests, or architecture.
---

# Team Review

Run a command-style parallel review in Codex. This skill adapts the Claude `team-review` idea to Codex using `spawn_agent`, local diff inspection, and a lead synthesis pass.

## Quick Start

Use this skill when the user explicitly asks for a team-style review, for example:

- `$team-review`
- `$team-review #142`
- `$team-review HEAD~3..HEAD`
- `$team-review src/auth`

## Review Flow

1. Resolve the review target.
   - PR number like `#142` or `142` -> use `gh pr view <N> --json title,body,files` and `gh pr diff <N>` when `gh` is available.
   - File or directory path -> inspect the named files directly.
   - Commit range like `HEAD~3..HEAD` -> use `git diff <range>`.
   - No argument -> use `git diff HEAD` and `git status --short`.
2. Stop early if there are no changes to review.
3. Size the review scope.
   - Tiny: 2 files or fewer and about 50 changed lines or fewer
   - Small: up to 5 files or about 100 changed lines
   - Medium: up to 15 files or about 500 changed lines
   - Large: anything bigger
4. Choose perspectives.
   - Tiny -> 2 perspectives
   - Small -> 2 perspectives
   - Medium -> 3 perspectives
   - Large -> 4 perspectives
   - High-risk override -> always include security and correctness/tests for auth, payment, secret, migration, or shared-infra changes
5. Launch parallel review agents.
   - This skill is an explicit request for multi-agent work, so `spawn_agent` is allowed.
   - Prefer `explorer` agents because review is read-only.
   - Assign perspectives from: correctness/tests, security, performance, architecture.
6. Synthesize findings in the lead agent.
   - De-duplicate overlapping findings.
   - Re-check the most severe claims locally against the actual diff or files before presenting them.
   - If `ROADMAP.md` exists, note whether a finding is already covered by a pending task, can be handled in a later task, or should block the next step.
7. Report findings with the normal Codex review bar.
   - Findings first, ordered by severity.
   - Use concrete file and line references.
   - Keep summaries brief.

## Codex-Native Adaptation

- Claude Agent Team -> Codex `spawn_agent`
- Claude `AskUserQuestion` -> one short plain-text question only when a decision is required
- Claude team cleanup/shutdown ceremony -> not needed as a user-visible phase in Codex; just wait for agents, integrate, then close them when done
- Claude hooks -> replace with lead-side validation and explicit file/line requirements

## Target Resolution

- Prefer non-interactive commands only.
- For PR review, collect:
  - title/body metadata
  - changed file list
  - unified diff
- For local review, collect:
  - changed file list
  - diff stats
  - direct file reads for the changed areas
- If the user gave only a vague target like "review the auth changes", resolve the closest matching files first with `rg` and ask one short clarifying question only if the scope remains ambiguous.

## Perspective Selection

Read [references/review-checklists.md](references/review-checklists.md) and load only the sections you need for the chosen perspectives.

Recommended perspective sets:

- Tiny:
  - correctness/tests
  - security/performance
- Small:
  - correctness/tests
  - security/edge cases
- Medium:
  - security
  - performance
  - correctness/tests
- Large:
  - security
  - performance
  - correctness/tests
  - architecture

## Scale And Lead Rules

- Tiny and Small reviews usually need 2 `explorer` agents.
- Medium reviews usually need 3 `explorer` agents.
- Large or high-risk reviews usually need 4 `explorer` agents.
- Prefer smaller reviewer models for ordinary tiny or small diffs, and prefer a stronger reviewer for security or architecture when the diff is large, high-risk, or cross-cutting.
- Lead stays focused on target resolution, reviewer prompt quality, de-duplication, and validation. Do not redo the entire review locally.
- Re-check every Critical finding locally against the actual diff before presenting it.
- If a Critical finding is still uncertain, or the change touches auth, payments, migrations, or shared infrastructure, cross-check the top one or two Critical findings with a second reviewer before presenting them as Critical.
- If reviewers disagree on severity, resolve the disagreement in synthesis and downgrade uncertain claims instead of dumping raw conflict on the user.

## Agent Prompt Template

When spawning a reviewer, include:

- role and perspective
- exact review target
- how to inspect the diff
- the relevant checklist section
- required output format

Use a prompt shaped like this:

```text
You are the {security/performance/correctness/architecture} reviewer.

Review target:
- {PR number | commit range | file list}

How to inspect:
- {gh pr diff N | git diff RANGE | inspect listed files directly}

Checklist:
- Load only the relevant section from references/review-checklists.md

Output requirements:
- Report only real findings.
- Every finding must include severity, file path, and line number when available.
- Focus on changed code and directly affected behavior.
- Keep output in three groups: Critical, Warning, Info.
- End with a short verdict: Approve, Request Changes, or Comment.
```

## Lead Rules

- Do not invent findings to satisfy a perspective.
- Treat reviewer outputs as inputs, not final truth.
- Re-check Critical findings locally before presenting them.
- If two agents disagree, resolve that conflict in the lead synthesis instead of dumping both raw opinions on the user.
- For high-risk reviews, prefer one extra cross-check over one extra weak perspective.
- Keep the final review aligned with the general Codex review style:
  - findings first
  - file references
  - risks and missing tests emphasized
- If the user wants inline review comments, emit `::code-comment` directives per finding in addition to the normal summary.

## ROADMAP Integration

- If `ROADMAP.md` exists, inspect whether each non-Info finding is:
  - already covered by a pending task
  - naturally handled in a later task
  - a blocker that should be fixed before the next task
- Do not edit `ROADMAP.md` by default for a standalone review.
- If the user explicitly wants the findings tracked, or the review is clearly part of an active workflow, add a `## 리뷰 발견사항 (YYYY-MM-DD)` section compatible with the existing workflow format.

Example:

```md
## 리뷰 발견사항 (2026-03-21)
> 출처: $team-review HEAD~3..HEAD

- [ ] 1. [보안] 인증 우회 가능성 수정 (Critical) — 대상: src/auth.ts:88
- [ ] 2. [테스트] 회귀 테스트 추가 (Warning) — 대상: tests/auth.test.ts:1
진행률: 0/2 (0%)
```

## Output

Default output shape:

1. Findings
   - Ordered by severity, highest first
   - One finding per bullet with file and line
2. ROADMAP note
   - Only if a roadmap exists or the user asked to track findings
3. Short close
   - overall verdict
   - residual risk or testing gap

If no findings are discovered, state that explicitly and mention any remaining confidence limits.
