# Team Review Checklists

Load only the section that matches the assigned review perspective.

## Correctness and Tests

- Logic errors
  - off-by-one or boundary mistakes
  - null or undefined handling gaps
  - incorrect branching or fallback behavior
  - accidental behavior changes in refactors
- Error handling
  - missing try/catch around parsing, I/O, or async boundaries
  - swallowed errors
  - user-facing errors that hide or overexpose details
- Types and contracts
  - unsafe casts or `any`
  - runtime validation gaps for external input
  - public contract changes without matching tests
- Test coverage
  - missing regression tests for new branches
  - edge cases not covered
  - mocks hiding real behavior changes

## Security

- Injection
  - SQL or NoSQL injection
  - command injection
  - XSS through rendered user input
- Auth and authorization
  - missing auth middleware
  - incorrect ownership or role checks
  - bypass paths introduced by new code
- Data handling
  - secrets or tokens in logs
  - sensitive data exposure in errors
  - hardcoded credentials or unsafe defaults
- Input validation
  - unbounded length or type assumptions
  - path traversal or unsafe upload handling
  - open redirect style issues

## Performance

- Complexity
  - quadratic or repeated scans in hot paths
  - repeated expensive transforms or serialization
- Data and storage
  - N+1 queries
  - missing filtering or over-broad selects
  - unnecessary full loads instead of streaming or paging
- Async and caching
  - sequential awaits that can be parallelized
  - missing caching on repeated pure work or external fetches
  - unnecessary invalidations
- Frontend or runtime behavior
  - avoidable rerenders
  - large imports or bundle regressions
  - listener leaks or resource retention

## Architecture

- Module boundaries
  - too many responsibilities in one file or function
  - cross-layer imports or leaking abstractions
- Consistency
  - mismatch with established project patterns
  - inconsistent error handling or naming
  - public API shape drift
- Maintainability
  - duplicated logic
  - magic values that should be config or shared constants
  - refactor that makes future extension harder
- Compatibility
  - breaking changes to public interfaces
  - schema or config changes without migration handling
