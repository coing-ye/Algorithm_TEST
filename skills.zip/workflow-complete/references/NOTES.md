This directory is reserved for future workflow-complete references.
