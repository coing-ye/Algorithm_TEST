---
name: workflow-complete
description: Close out the current workflow task in Codex by validating completion evidence, updating `ROADMAP.md`, syncing `update_plan`, and deciding the next step.
---

# Workflow Complete

Use this after a task has been executed and the workflow needs closeout or next-step routing.

This is primarily an internal phase skill behind `$workflow`. Prefer `$workflow` for normal usage unless the user explicitly wants closeout behavior or the router is not needed.

## Completion Flow

1. Detect the workspace root and read `ROADMAP.md`.
   - Prefer `../workflow/scripts/roadmap_state.py <root> --json` first so closeout uses the same task recovery logic as the other phases.
2. Confirm the true completion state.
   - Review the relevant changed files.
   - Review the verification commands that were actually run.
   - Do not mark completion without file evidence and validation evidence.
   - If the task is already marked complete and already has a nearby `변경:` note, do not duplicate closeout bookkeeping. Move straight to next-step logic.
3. Update the roadmap.
   - Prefer `../workflow/scripts/roadmap_update.py <root> complete --task N --date YYYY-MM-DD --change "..."` for the mechanical parts of closeout.
   - Mark the finished item `- [x]` and add the completion date when useful.
   - Add a `변경:` line with key files and one-line summaries.
   - Remove or replace stale `🔄 진행 중` markers.
   - Recalculate `진행률:`.
   - If the task should stop without completion, use the block or cancel path instead of forcing a done state.
4. Sync `update_plan`.
   - Completed task -> `completed`
   - Next runnable task -> `pending` or `in_progress` depending on whether execution should continue immediately
5. Decide the next step.
   - `모드: 자동진행` and another runnable task exists -> continue with `$workflow-run`
   - `모드: 개별선택` or `모드: 대기 중` and another runnable task exists -> recommend the next task and ask one short plain-text question
   - Important changes landed and the user wants extra confidence -> recommend `$team-review` as an explicit follow-up
   - In `모드: 자동진행`, defer non-security review suggestions until the final runnable task unless the change is security-sensitive
   - No runnable tasks remain -> summarize workflow completion and obvious follow-up options if relevant

## Review Trigger Heuristics

Suggest `$team-review` when one or more of these is true:

- about 5 or more changed files
- about 200 or more changed lines
- auth, security, crypto, token, session, password, secret, billing, payments, schema, migration, or shared infrastructure files changed
- a new directory or new module entrypoint was added
- the completed task implemented a design-sensitive area recorded in `## 설계 결정`

Usually skip the review suggestion when the change is only:

- tests
- docs or config
- a single-file bug fix around 10 lines or fewer
- a narrow bug fix that already went through `$team-debug`, unless the resulting change is security-sensitive or unexpectedly broad

When inside a repository, use quick evidence commands such as:

```bash
git diff --stat HEAD
git diff --name-only HEAD
git diff --diff-filter=A --name-only HEAD
```

## Codex-Native Rules

- Codex does not have Claude's `TaskList`, `AskUserQuestion`, or built-in handoff hooks here, so use `ROADMAP.md`, `update_plan`, and short direct questions instead.
- Keep completion based on actual evidence, not intent.
- Preserve prior `변경:` notes and valid history.
- `git commit`, `git push`, PR creation, and external review are opt-in follow-up actions. Do not perform or promise them silently.
- Do not fabricate metrics, review outcomes, or automation side effects that did not happen.
- If the task touched auth, security boundaries, payments, schema or migration behavior, shared infrastructure, or a broad refactor, suggest `$team-review` once when a second-pass review would materially reduce risk.
- In automatic mode, prefer deferring non-security review prompts until the workflow reaches a natural stopping point so the flow is not interrupted after every task.
- If the roadmap is in automatic mode, continue with the next runnable task. Otherwise stop after a concise status and ask at most one short question if needed.

## Output

End with a short summary of:
- task closed out
- roadmap changes
- verification confirmed
- whether the next task is ready or the workflow is finished
- whether `$team-review` is worth running now, should be deferred, or can be skipped
