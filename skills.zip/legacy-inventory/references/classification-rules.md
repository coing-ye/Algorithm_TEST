# Classification Rules

This skill uses source-derived heuristics to classify files into renewal planning buckets.

## Primary categories

- `frontend`
  - JSP, HTML, TSX, JSX, Vue, and similar view files
  - Java or server-side entrypoints under folders like `action`, `controller`, `pages`, `views`, `screens`
- `backend`
  - Service, biz, manager, repository, DAO, domain, entity, model, and command-oriented code
  - SQL assets that support internal business logic without strong integration signals
- `batch`
  - Files under `task`, `batch`, `job`, `scheduler`, `cron`, `worker`, `loader`, `migration`, `publish`
- `interface`
  - Files under or named with `proxy`, `adapter`, `interface`, `intf`, `servlet`, `api`, `ftp`, `sso`, `oauth`, `integration`, `eai`
  - SQL packages or assets clearly tied to integrations such as `EAI`, `ERP`, `PMS`, `MDM`, `HR`

The extractor chooses one primary category per file. Batch and interface signals take precedence over frontend and backend so that schedulers and integrations do not get buried.

## Module extraction

The script tries to infer a business module from path structure.

Examples:

- `src/plm/part/biz/PTRBiz.java` -> module `part`
- `codebase/plmhome/jsp/bom/BOMManageList.jsp` -> module `bom`
- `src/plm/workflow/task/WFMTask.java` -> module `workflow`

It skips generic path segments such as:

- `src`
- `main`
- `java`
- `resources`
- `codebase`
- `webapp`
- `WEB-INF`
- `plm`
- `com`
- `org`

## Priority and difficulty

The workbook includes planning-oriented fields:

- `priority`
  - high for common renewal hotspots like BOM, CAD, part, workflow, change management, or key interfaces
  - medium for most support areas and integration work
  - low for smaller or more isolated utility areas
- `difficulty`
  - high for cross-cutting business logic, heavy interfaces, and migration-heavy assets
  - medium for most ordinary services and batches
  - low for simple UI or admin/support features

Treat these as starting points, not contractual estimates.

## Module map overrides

When the user wants customer-facing naming, create a JSON file and pass it with `--module-map`.

Example:

```json
{
  "display_names": {
    "bomreg": "BOM Registration",
    "ecm": "Engineering Change"
  },
  "level1_groups": {
    "bomreg": "Product Structure/BOM",
    "ecm": "Change Management"
  },
  "priority_overrides": {
    "ecm": "high",
    "admin": "medium"
  },
  "difficulty_overrides": {
    "workflow": "high",
    "portal": "low"
  }
}
```

Supported keys:

- `display_names`
- `level1_groups`
- `priority_overrides`
- `difficulty_overrides`
- `owner_overrides`
- `asis_tobe_overrides`

Each override key maps the inferred module id to a replacement value.

## Reporting guidance

- Report that names are source-derived.
- Keep evidence paths visible.
- When the project is very old or heavily customized, expect one tuning pass after SME review.
