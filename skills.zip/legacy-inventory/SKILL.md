---
name: legacy-inventory
description: Analyze existing or legacy software projects and extract a renewal-ready inventory from source code. Use when the user asks to understand an inherited codebase, prepare AS-IS materials for modernization, build a frontend/backend/batch/interface feature list, create Excel or CSV inventories from source folders, summarize modules and integration points, or estimate renewal scope from project structure.
---

# Legacy Inventory

## Overview

Use this skill to turn a legacy project tree into a structured inventory for renewal planning. The default output is a workbook with representative items, full inventory rows, module summaries, and evidence paths.

Do not use this skill for code review of a diff or PR. Use `$team-review` for review work.

## Quick Start

1. Confirm the project root and whether the user wants a quick summary or a full inventory.
2. Run `scripts/scan_legacy_inventory.py` to generate the workbook.
3. Review the representative sheet first, then the full inventory, and call out that the names are source-derived and should be validated with SMEs.

Example:

```powershell
python scripts/scan_legacy_inventory.py `
  --root "C:\path\to\legacy-project" `
  --system-name "Legacy PLM" `
  --output "C:\path\to\output\legacy_inventory.xlsx"
```

Optional:

- Add `--module-map <json>` when the project needs business-friendly module names or group overrides.
- Add `--representative-limit 5` when the user wants more examples per module.

## Workflow

### 1. Inspect the root before extraction

- Read the top-level directories and dominant file types.
- Confirm whether the project is monolithic or split across multiple roots.
- If the user gave a large parent directory, narrow to the actual source root first.

### 2. Choose the right scope

- Use a full-root scan for renewal planning, RFP preparation, and AS-IS inventory requests.
- Use a narrowed module or folder path for deep dives or incremental analysis.
- If the repository contains third-party bundles, generated artifacts, or vendor folders, keep them out of scope unless the user explicitly wants them analyzed.

### 3. Run the deterministic extractor

Use `scripts/scan_legacy_inventory.py` for repeatable output instead of manually reconstructing the workbook each time.

The script produces:

- `representative_inventory`
- `full_inventory`
- `frontend`
- `backend`
- `batch`
- `interface`
- `module_summary`
- `tech_stack`
- `assumptions`

### 4. Review and refine

- Open the representative sheet first.
- Translate file-derived names into business-facing names when useful.
- If module names are too technical, prepare a `module-map` JSON and rerun.
- If the user needs a Korean or customer-specific format, adapt the workbook headers after extraction instead of weakening the extraction rules.

### 5. Report carefully

- State that the inventory is source-derived, not business-validated truth.
- Call out likely blind spots such as scheduler definitions, hidden integrations, database jobs, or externally configured interfaces.
- Separate evidence-backed facts from inference.

## Classification Guidance

Read [references/classification-rules.md](references/classification-rules.md) when:

- the project mixes web, batch, interface, and DB assets
- module names need overrides
- the user asks why a file landed in frontend/backend/batch/interface
- the default heuristics need tuning for a framework or naming convention

## Script Usage

Use the script at [scripts/scan_legacy_inventory.py](scripts/scan_legacy_inventory.py).

Arguments:

- `--root`: project root to scan
- `--system-name`: display name used in the workbook
- `--output`: target `.xlsx` path
- `--module-map`: optional JSON file with module display and grouping overrides
- `--representative-limit`: number of sample rows per module and dev type in the representative sheet

## Output Standards

- Prefer an Excel workbook when the user wants a handoff artifact.
- Keep a representative sheet and a full detail sheet together.
- Include evidence paths in the workbook.
- Include ownership, AS-IS/TO-BE hint, difficulty, and priority as planning aids, not final commitments.

## Notes

- Default heuristics work best for Java and server-rendered legacy web systems, but they are still useful for mixed repositories.
- For project-specific terminology, prefer a `module-map` override over hardcoding one-off rules into the script.
