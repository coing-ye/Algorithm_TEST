from __future__ import annotations

import argparse
import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


IGNORE_DIRS = {
    ".git",
    ".hg",
    ".idea",
    ".svn",
    ".vscode",
    "__pycache__",
    "bin",
    "build",
    "coverage",
    "dist",
    "node_modules",
    "obj",
    "out",
    "target",
    "vendor",
}

RELEVANT_EXTS = {
    ".java",
    ".jsp",
    ".jspx",
    ".jspf",
    ".html",
    ".htm",
    ".tsx",
    ".jsx",
    ".vue",
    ".py",
    ".kt",
    ".cs",
    ".go",
    ".rb",
    ".php",
    ".xml",
    ".yml",
    ".yaml",
    ".sql",
    ".properties",
}

FRONTEND_EXTS = {".jsp", ".jspx", ".jspf", ".html", ".htm", ".tsx", ".jsx", ".vue"}
SKIP_EXTS = {
    ".bmp",
    ".class",
    ".dll",
    ".exe",
    ".gif",
    ".ico",
    ".jar",
    ".jpeg",
    ".jpg",
    ".lock",
    ".min.js",
    ".pdf",
    ".png",
    ".svg",
    ".ttf",
    ".woff",
    ".woff2",
}

GENERIC_SEGMENTS = {
    "app",
    "apps",
    "code",
    "codebase",
    "com",
    "java",
    "main",
    "netmarkets",
    "org",
    "plm",
    "resources",
    "src",
    "source",
    "sources",
    "web",
    "web-inf",
    "webapp",
}

GROUP_KEYWORDS = {
    "admin": "Common/Admin",
    "auth": "Common/Auth",
    "bom": "Product Structure/BOM",
    "cad": "Design/CAD",
    "cae": "Design/CAE",
    "common": "Common/Core",
    "cpc": "External Distribution",
    "dfmea": "Quality/FMEA",
    "doc": "Document/Request",
    "document": "Document/Request",
    "dn": "Download/Spec",
    "ecm": "Change Management",
    "eco": "Change Management",
    "ekm": "Knowledge/Document",
    "hr": "Interface/HR",
    "interface": "Interface",
    "login": "Common/Auth",
    "material": "Material/Library",
    "migration": "Data Migration",
    "mim": "Manufacturing/Mask",
    "part": "Part Management",
    "pms": "Interface/PMS",
    "portal": "Common/Portal",
    "project": "Project Management",
    "prt": "Part Management",
    "quality": "Quality/FMEA",
    "sso": "Common/Auth",
    "vds": "Design/Drawing",
    "workflow": "Workflow/Approval",
}

HIGH_PRIORITY_KEYWORDS = {"bom", "cad", "change", "ecm", "eco", "interface", "part", "pms", "prt", "workflow"}
MEDIUM_PRIORITY_KEYWORDS = {"admin", "common", "dfmea", "doc", "dn", "ekm", "material", "migration", "mim", "portal", "vds"}
HIGH_DIFFICULTY_KEYWORDS = {"bom", "cad", "change", "ecm", "eco", "interface", "migration", "part", "pms", "workflow"}
LOW_DIFFICULTY_KEYWORDS = {"admin", "auth", "common", "login", "portal"}

HEADER_FILL = PatternFill("solid", fgColor="2F2F2F")
SECTION_FILLS = {
    "Frontend": PatternFill("solid", fgColor="F4F4F4"),
    "Backend": PatternFill("solid", fgColor="EAF2F8"),
    "Batch": PatternFill("solid", fgColor="FCF3CF"),
    "Interface": PatternFill("solid", fgColor="E8F8F5"),
}
THIN = Side(style="thin", color="BFBFBF")
CELL_BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


@dataclass(frozen=True)
class InventoryRow:
    system: str
    level1: str
    level2: str
    level3: str
    notes: str
    level3_type: str
    dev_code: str
    dev_full: str
    priority: str
    asis_tobe: str
    owner_area: str
    difficulty: str
    evidence: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Scan a legacy project and build a renewal inventory workbook.")
    parser.add_argument("--root", required=True, help="Project root to scan")
    parser.add_argument("--system-name", default="", help="Workbook system name; defaults to the root folder name")
    parser.add_argument("--output", default="", help="Output .xlsx path")
    parser.add_argument("--module-map", default="", help="Optional JSON file with module overrides")
    parser.add_argument("--representative-limit", type=int, default=3, help="Rows per module/dev type in representative sheet")
    return parser.parse_args()


def load_module_map(path_value: str) -> dict:
    if not path_value:
        return {}
    path = Path(path_value)
    if not path.exists():
        raise FileNotFoundError(f"Module map not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def iter_files(root: Path) -> Iterable[Path]:
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if any(part in IGNORE_DIRS for part in path.parts):
            continue
        suffix = path.suffix.lower()
        name = path.name.lower()
        if suffix in SKIP_EXTS or name.endswith(".min.js"):
            continue
        yield path


def split_words(name: str) -> list[str]:
    text = name.replace("_", " ").replace("-", " ")
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", text)
    text = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1 \2", text)
    return [part for part in text.split() if part]


def humanize(name: str) -> str:
    return " ".join(split_words(name))


def rel(root: Path, path: Path) -> str:
    return path.relative_to(root).as_posix()


def first_non_generic(parts: list[str]) -> str:
    for part in parts:
        lower = part.lower()
        if lower in GENERIC_SEGMENTS:
            continue
        if lower in {"action", "adapter", "api", "batch", "biz", "cmd", "command", "controller", "dao", "domain", "entity", "interface", "intf", "job", "loader", "manager", "migration", "model", "pages", "proxy", "repository", "rest", "scheduler", "screens", "service", "servlet", "task", "views", "worker"}:
            continue
        if not re.search(r"[a-zA-Z]", part):
            continue
        return lower
    return "common"


def infer_module(path: Path) -> str:
    parts = list(path.parts)
    lowered = [part.lower() for part in parts]
    for marker in ("jsp", "pages", "views", "screens"):
        if marker in lowered:
            idx = lowered.index(marker)
            if idx + 1 < len(parts):
                return first_non_generic([parts[idx + 1]])
    for marker in ("src", "codebase", "webapp"):
        if marker in lowered:
            idx = lowered.index(marker)
            return first_non_generic(parts[idx + 1 : -1])
    return first_non_generic(parts[:-1])


def infer_group(module: str, overrides: dict) -> str:
    if module in overrides.get("level1_groups", {}):
        return overrides["level1_groups"][module]
    for keyword, group in GROUP_KEYWORDS.items():
        if keyword in module:
            return group
    return "Other"


def infer_display_name(module: str, overrides: dict) -> str:
    if module in overrides.get("display_names", {}):
        return overrides["display_names"][module]
    return humanize(module).title()


def classify_file(path: Path) -> tuple[str, str, str] | None:
    suffix = path.suffix.lower()
    lowered_parts = [part.lower() for part in path.parts]
    joined = "/".join(lowered_parts)
    stem = path.stem.lower()

    is_batch = any(token in lowered_parts for token in {"batch", "job", "loader", "migration", "publish", "scheduler", "task", "worker"})
    is_interface = any(token in lowered_parts for token in {"adapter", "api", "eai", "ftp", "intf", "interface", "oauth", "proxy", "rest", "servlet", "sso", "ws"}) or any(
        token in stem for token in {"adapter", "eai", "erp", "ftp", "interface", "oauth", "proxy", "pms", "rest", "servlet", "sso"}
    )
    is_frontend = suffix in FRONTEND_EXTS or any(token in lowered_parts for token in {"action", "controller", "jsp", "pages", "screens", "views"})

    if is_batch:
        return ("BATCH", "Batch", "batch")
    if is_interface:
        return ("IF", "Interface", "interface")
    if is_frontend:
        return ("WEB", "Frontend", "screen")
    if suffix in RELEVANT_EXTS:
        return ("BE", "Backend", "service")
    if suffix == ".sql":
        if any(token in joined for token in ("eai", "erp", "hr", "mdm", "pms")):
            return ("IF", "Interface", "interface")
        return ("BE", "Backend", "db")
    return None


def strip_suffixes(name: str) -> str:
    suffixes = (
        "Action",
        "Adapter",
        "AjaxCmd",
        "Biz",
        "Cmd",
        "Command",
        "Controller",
        "Dao",
        "Entity",
        "Form",
        "Helper",
        "Interface",
        "Job",
        "Loader",
        "Manager",
        "Migration",
        "Model",
        "Proxy",
        "Repository",
        "Service",
        "Servlet",
        "Task",
        "Util",
        "Worker",
    )
    title = path_safe_name(name)
    for suffix in suffixes:
        if title.endswith(suffix):
            return title[: -len(suffix)] or title
    return title


def path_safe_name(name: str) -> str:
    return name.replace(".java", "").replace(".jsp", "").replace(".xml", "")


def infer_level3(path: Path, dev_full: str, level3_type: str) -> str:
    base = strip_suffixes(path.stem)
    title = humanize(base).strip() or path.stem
    suffix_map = {
        "screen": "Screen",
        "service": "Service",
        "batch": "Batch",
        "interface": "Interface",
        "db": "DB Asset",
    }
    return f"{title} {suffix_map[level3_type]}".strip()


def infer_notes(category_reason: str, evidence: str) -> str:
    return f"{category_reason} | Evidence: {evidence}"


def infer_priority(module: str, dev_full: str, overrides: dict) -> str:
    if module in overrides.get("priority_overrides", {}):
        return overrides["priority_overrides"][module]
    if any(keyword in module for keyword in HIGH_PRIORITY_KEYWORDS):
        return "high"
    if any(keyword in module for keyword in MEDIUM_PRIORITY_KEYWORDS) or dev_full in {"Batch", "Interface"}:
        return "medium"
    return "low"


def infer_asis_tobe(module: str, dev_full: str, overrides: dict) -> str:
    if module in overrides.get("asis_tobe_overrides", {}):
        return overrides["asis_tobe_overrides"][module]
    if "migration" in module:
        return "AS-IS migration asset / TO-BE standardized migration flow"
    mapping = {
        "Frontend": "AS-IS legacy UI / TO-BE renewed UX and screens",
        "Backend": "AS-IS business logic / TO-BE service and API restructuring",
        "Batch": "AS-IS scheduled jobs / TO-BE standardized batch and migration flow",
        "Interface": "AS-IS point integrations / TO-BE standardized integration contracts",
    }
    return mapping[dev_full]


def infer_owner(dev_full: str, module: str, overrides: dict) -> str:
    if module in overrides.get("owner_overrides", {}):
        return overrides["owner_overrides"][module]
    mapping = {
        "Frontend": "Frontend",
        "Backend": "Backend",
        "Batch": "Batch/Ops",
        "Interface": "Interface/EAI",
    }
    return mapping[dev_full]


def infer_difficulty(module: str, dev_full: str, overrides: dict) -> str:
    if module in overrides.get("difficulty_overrides", {}):
        return overrides["difficulty_overrides"][module]
    if any(keyword in module for keyword in HIGH_DIFFICULTY_KEYWORDS):
        return "high"
    if any(keyword in module for keyword in LOW_DIFFICULTY_KEYWORDS) and dev_full == "Frontend":
        return "low"
    if dev_full == "Interface":
        return "high"
    return "medium"


def row_key(row: InventoryRow) -> tuple[str, str, str, str]:
    return (row.dev_full, row.level2, row.level3, row.evidence)


def collect_inventory(root: Path, system_name: str, overrides: dict) -> list[InventoryRow]:
    rows: dict[tuple[str, str, str, str], InventoryRow] = {}
    for path in iter_files(root):
        classification = classify_file(path)
        if not classification:
            continue
        dev_code, dev_full, level3_type = classification
        evidence = rel(root, path)
        module = infer_module(path)
        level1 = infer_group(module, overrides)
        level2 = infer_display_name(module, overrides)
        category_reason = f"Source-derived {dev_full.lower()} classification"
        row = InventoryRow(
            system=system_name,
            level1=level1,
            level2=level2,
            level3=infer_level3(path, dev_full, level3_type),
            notes=infer_notes(category_reason, evidence),
            level3_type=level3_type.title(),
            dev_code=dev_code,
            dev_full=dev_full,
            priority=infer_priority(module, dev_full, overrides),
            asis_tobe=infer_asis_tobe(module, dev_full, overrides),
            owner_area=infer_owner(dev_full, module, overrides),
            difficulty=infer_difficulty(module, dev_full, overrides),
            evidence=evidence,
        )
        rows[row_key(row)] = row
    return sort_rows(rows.values())


def sort_rows(rows: Iterable[InventoryRow]) -> list[InventoryRow]:
    order = {"Frontend": 0, "Backend": 1, "Batch": 2, "Interface": 3}
    return sorted(rows, key=lambda row: (order[row.dev_full], row.level1, row.level2, row.level3, row.evidence))


def representative_rows(items: list[InventoryRow], limit: int) -> list[InventoryRow]:
    grouped: dict[tuple[str, str, str], list[InventoryRow]] = defaultdict(list)
    for row in items:
        grouped[(row.dev_full, row.level1, row.level2)].append(row)
    selected: list[InventoryRow] = []
    for key in sorted(grouped):
        selected.extend(grouped[key][:limit])
    return selected


def style_header(ws, headers: list[str]) -> None:
    for col, header in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.fill = HEADER_FILL
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = CELL_BORDER


def style_rows(ws, row_count: int, last_col: int) -> None:
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(last_col)}{row_count + 1}"
    ws.row_dimensions[1].height = 28
    for row_idx in range(2, row_count + 2):
        fill = SECTION_FILLS.get(ws.cell(row=row_idx, column=9).value)
        for col_idx in range(1, last_col + 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = CELL_BORDER
            if fill:
                cell.fill = fill


def write_inventory_sheet(wb: Workbook, name: str, items: list[InventoryRow]) -> None:
    ws = wb.create_sheet(name)
    headers = [
        "No",
        "System",
        "Level-1",
        "Level-2",
        "Level-3",
        "Notes",
        "Level-3 Type",
        "Dev Type Code",
        "Dev Type",
        "Priority",
        "AS-IS/TO-BE",
        "Owner Area",
        "Difficulty",
        "Evidence Path",
    ]
    widths = [8, 18, 20, 22, 34, 54, 14, 14, 14, 10, 34, 16, 10, 54]
    style_header(ws, headers)
    for index, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(index)].width = width
    for row_idx, row in enumerate(items, start=2):
        values = [
            row_idx - 1,
            row.system,
            row.level1,
            row.level2,
            row.level3,
            row.notes,
            row.level3_type,
            row.dev_code,
            row.dev_full,
            row.priority,
            row.asis_tobe,
            row.owner_area,
            row.difficulty,
            row.evidence,
        ]
        for col_idx, value in enumerate(values, start=1):
            ws.cell(row=row_idx, column=col_idx, value=value)
    style_rows(ws, len(items), len(headers))


def write_module_summary(wb: Workbook, items: list[InventoryRow]) -> None:
    ws = wb.create_sheet("module_summary")
    headers = ["Level-1", "Level-2", "Frontend", "Backend", "Batch", "Interface", "Total"]
    style_header(ws, headers)
    counts: dict[tuple[str, str], Counter] = defaultdict(Counter)
    for row in items:
        counts[(row.level1, row.level2)][row.dev_full] += 1
    for row_idx, ((level1, level2), counter) in enumerate(sorted(counts.items()), start=2):
        total = counter["Frontend"] + counter["Backend"] + counter["Batch"] + counter["Interface"]
        values = [level1, level2, counter["Frontend"], counter["Backend"], counter["Batch"], counter["Interface"], total]
        for col_idx, value in enumerate(values, start=1):
            ws.cell(row=row_idx, column=col_idx, value=value)
            ws.cell(row=row_idx, column=col_idx).border = CELL_BORDER
    for index, width in enumerate([22, 22, 12, 12, 12, 12, 12], start=1):
        ws.column_dimensions[get_column_letter(index)].width = width
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:G{ws.max_row}"


def write_tech_stack(wb: Workbook, root: Path) -> None:
    ws = wb.create_sheet("tech_stack")
    style_header(ws, ["Item", "Value"])
    top_dirs = [path.name for path in root.iterdir() if path.is_dir()][:20]
    ext_counter: Counter = Counter()
    for path in iter_files(root):
        ext = path.suffix.lower() or "<none>"
        ext_counter[ext] += 1
    rows = [
        ("Root", str(root)),
        ("Top directories", ", ".join(top_dirs) or "<none>"),
        ("Top extensions", ", ".join(f"{ext}:{count}" for ext, count in ext_counter.most_common(15))),
    ]
    for row_idx, (left, right) in enumerate(rows, start=2):
        ws.cell(row=row_idx, column=1, value=left)
        ws.cell(row=row_idx, column=2, value=right)
        ws.cell(row=row_idx, column=1).border = CELL_BORDER
        ws.cell(row=row_idx, column=2).border = CELL_BORDER
    ws.column_dimensions["A"].width = 20
    ws.column_dimensions["B"].width = 120


def write_assumptions(wb: Workbook, root: Path, overrides: dict, representative_limit: int, item_count: int) -> None:
    ws = wb.create_sheet("assumptions")
    style_header(ws, ["Item", "Value"])
    rows = [
        ("Root", str(root)),
        ("Generated by", "legacy-inventory/scripts/scan_legacy_inventory.py"),
        ("Representative limit", representative_limit),
        ("Module map applied", "yes" if overrides else "no"),
        ("Classification basis", "source-derived path, filename, and suffix heuristics"),
        ("Reminder", "Validate module names and priorities with SMEs before final planning"),
        ("Inventory rows", item_count),
    ]
    for row_idx, (left, right) in enumerate(rows, start=2):
        ws.cell(row=row_idx, column=1, value=left)
        ws.cell(row=row_idx, column=2, value=right)
        ws.cell(row=row_idx, column=1).border = CELL_BORDER
        ws.cell(row=row_idx, column=2).border = CELL_BORDER
    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 120


def output_path(root: Path, system_name: str, requested: str) -> Path:
    if requested:
        return Path(requested)
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", system_name).strip("_") or "legacy_inventory"
    return root.parent / f"{safe}_legacy_inventory.xlsx"


def build_workbook(items: list[InventoryRow], root: Path, destination: Path, representative_limit: int, overrides: dict) -> None:
    wb = Workbook()
    wb.remove(wb.active)
    write_inventory_sheet(wb, "representative_inventory", representative_rows(items, representative_limit))
    write_inventory_sheet(wb, "full_inventory", items)
    for dev_full, sheet_name in [("Frontend", "frontend"), ("Backend", "backend"), ("Batch", "batch"), ("Interface", "interface")]:
        write_inventory_sheet(wb, sheet_name, [row for row in items if row.dev_full == dev_full])
    write_module_summary(wb, items)
    write_tech_stack(wb, root)
    write_assumptions(wb, root, overrides, representative_limit, len(items))
    wb["representative_inventory"].sheet_view.tabSelected = True
    destination.parent.mkdir(parents=True, exist_ok=True)
    wb.save(destination)


def main() -> None:
    args = parse_args()
    root = Path(args.root).expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(f"Root not found: {root}")
    system_name = args.system_name or root.name
    overrides = load_module_map(args.module_map)
    items = collect_inventory(root, system_name, overrides)
    destination = output_path(root, system_name, args.output)
    build_workbook(items, root, destination, args.representative_limit, overrides)

    counts = Counter(row.dev_full for row in items)
    print(f"Output: {destination}")
    print(f"Total rows: {len(items)}")
    print(
        "Counts: "
        f"frontend={counts['Frontend']}, "
        f"backend={counts['Backend']}, "
        f"batch={counts['Batch']}, "
        f"interface={counts['Interface']}"
    )


if __name__ == "__main__":
    main()
